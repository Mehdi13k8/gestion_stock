--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7
-- Dumped by pg_dump version 10.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.gestion_stock_zonedepot_pour_typezonedepot DROP CONSTRAINT "gestion_stock_zonede_fk_TypeZoneDepot_id_2d3337f8_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_unitemanutentionsortie DROP CONSTRAINT "gestion_stock_unitem_fk_BonLivraisonSorti_e418aaf9_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_unitemanutentionentree DROP CONSTRAINT "gestion_stock_unitem_fk_BonLivraisonEntre_077f0e37_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_unitemanutentionsortie DROP CONSTRAINT "gestion_stock_unitem_fk_BonCommandeSortie_678ef194_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie DROP CONSTRAINT "gestion_stock_ligneb_fk_Transporteur_id_e0b4694c_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie DROP CONSTRAINT "gestion_stock_ligneb_fk_BonLivraisonSorti_98e360b6_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree DROP CONSTRAINT "gestion_stock_ligneb_fk_BonLivraisonEntre_3f146f68_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie DROP CONSTRAINT "gestion_stock_ligneb_fk_BonCommandeSortie_e1eaff1a_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree DROP CONSTRAINT "gestion_stock_ligneb_fk_BonCommandeEntree_32310d1e_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie DROP CONSTRAINT "gestion_stock_ligneb_fk_Article_id_9eee0e5e_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree DROP CONSTRAINT "gestion_stock_ligneb_fk_Article_id_48a1d197_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree DROP CONSTRAINT "gestion_stock_ligneb_fk_Article_id_35f597d6_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie DROP CONSTRAINT "gestion_stock_ligneb_fk_Article_id_2079106f_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_lettrevoitureentree DROP CONSTRAINT "gestion_stock_lettre_fk_Transporteur_id_b4dbf6db_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_lettrevoituresortie DROP CONSTRAINT "gestion_stock_lettre_fk_Transporteur_id_81d31722_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_fournisseur DROP CONSTRAINT "gestion_stock_fourni_fk_TypeFournisseur_i_9a2685c4_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_destinataire DROP CONSTRAINT "gestion_stock_destin_fk_TypeDestinataire__473bb345_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_destinataire DROP CONSTRAINT "gestion_stock_destin_fk_Pays_id_f2f9f054_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_contact_pour_client DROP CONSTRAINT "gestion_stock_contac_fk_RoleContact_id_17dd98ed_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_contact_pour_client DROP CONSTRAINT "gestion_stock_contac_fk_Client_id_29a22d77_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_colis DROP CONSTRAINT gestion_stock_colis_fk_litige_id_87e26c63_fk_gestion_s;
ALTER TABLE ONLY public.gestion_stock_colis DROP CONSTRAINT "gestion_stock_colis_fk_ZoneDepot_id_8b581af3_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_colis DROP CONSTRAINT "gestion_stock_colis_fk_UniteManutentionS_4a8b42f0_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_colis DROP CONSTRAINT "gestion_stock_colis_fk_UniteManutentionE_16c75c12_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_colis DROP CONSTRAINT "gestion_stock_colis_fk_LitigeDecision_id_75ff08bd_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_colis DROP CONSTRAINT "gestion_stock_colis_fk_Article_id_4aa25755_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_client DROP CONSTRAINT "gestion_stock_client_fk_TypeZone_id_a48ba631_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_client DROP CONSTRAINT "gestion_stock_client_fk_TypeFournisseur_i_0cbea6bf_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_client DROP CONSTRAINT "gestion_stock_client_fk_TypeDestinataire__d5074d84_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_client DROP CONSTRAINT "gestion_stock_client_fk_TypeArticle_id_1af52016_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree DROP CONSTRAINT "gestion_stock_bonliv_fk_ZoneDepot_pour_Ty_ad6ef601_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree DROP CONSTRAINT "gestion_stock_bonliv_fk_TypeZoneDepot_id_e0d5dce3_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_bonlivraisonsortie DROP CONSTRAINT "gestion_stock_bonliv_fk_LettreVoitureSort_d498587e_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree DROP CONSTRAINT "gestion_stock_bonliv_fk_LettreVoitureEntr_bd1beab9_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree DROP CONSTRAINT "gestion_stock_bonliv_fk_Fournisseur_id_a14cc499_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree DROP CONSTRAINT "gestion_stock_bonliv_fk_Destinataire_id_0b3e4c09_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree DROP CONSTRAINT "gestion_stock_bonliv_fk_Client_id_17e7f6cb_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_bonlivraisonsortie DROP CONSTRAINT "gestion_stock_bonliv_fk_BonCommandeSortie_312cf0b1_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_boncommandesortie DROP CONSTRAINT "gestion_stock_boncom_fk_Transporteur_id_6d260680_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_boncommandesortie DROP CONSTRAINT "gestion_stock_boncom_fk_Destinataire_id_3ca2e851_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_boncommandesortie DROP CONSTRAINT "gestion_stock_boncom_fk_Client_id_d89f031e_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_article DROP CONSTRAINT "gestion_stock_articl_fk_TypeArticle_id_df0d768b_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_article DROP CONSTRAINT "gestion_stock_articl_fk_Fournisseur_id_af746084_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_article_historique_pour_article DROP CONSTRAINT "gestion_stock_articl_fk_Fournisseur_id_26a4d479_fk_gestion_s";
ALTER TABLE ONLY public.gestion_stock_article_historique_pour_article DROP CONSTRAINT "gestion_stock_articl_fk_Article_id_cc2ae50c_fk_gestion_s";
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
DROP INDEX public."gestion_stock_zonedepot_po_fk_TypeZoneDepot_id_2d3337f8";
DROP INDEX public."gestion_stock_unitemanuten_fk_BonLivraisonSortie_id_e418aaf9";
DROP INDEX public."gestion_stock_unitemanuten_fk_BonLivraisonEntree_id_077f0e37";
DROP INDEX public."gestion_stock_unitemanuten_fk_BonCommandeSortie_id_678ef194";
DROP INDEX public."gestion_stock_lignebonlivr_fk_Transporteur_id_e0b4694c";
DROP INDEX public."gestion_stock_lignebonlivr_fk_BonLivraisonSortie_id_98e360b6";
DROP INDEX public."gestion_stock_lignebonlivr_fk_BonLivraisonEntree_id_3f146f68";
DROP INDEX public."gestion_stock_lignebonlivr_fk_Article_id_48a1d197";
DROP INDEX public."gestion_stock_lignebonlivr_fk_Article_id_2079106f";
DROP INDEX public."gestion_stock_ligneboncomm_fk_BonCommandeSortie_id_e1eaff1a";
DROP INDEX public."gestion_stock_ligneboncomm_fk_BonCommandeEntree_id_32310d1e";
DROP INDEX public."gestion_stock_ligneboncomm_fk_Article_id_9eee0e5e";
DROP INDEX public."gestion_stock_ligneboncomm_fk_Article_id_35f597d6";
DROP INDEX public."gestion_stock_lettrevoituresortie_fk_Transporteur_id_81d31722";
DROP INDEX public."gestion_stock_lettrevoitureentree_fk_Transporteur_id_b4dbf6db";
DROP INDEX public."gestion_stock_fournisseur_fk_TypeFournisseur_id_9a2685c4";
DROP INDEX public."gestion_stock_destinataire_fk_TypeDestinataire_id_473bb345";
DROP INDEX public."gestion_stock_destinataire_fk_Pays_id_f2f9f054";
DROP INDEX public."gestion_stock_contact_pour_client_fk_RoleContact_id_17dd98ed";
DROP INDEX public."gestion_stock_contact_pour_client_fk_Client_id_29a22d77";
DROP INDEX public.gestion_stock_colis_fk_litige_id_87e26c63;
DROP INDEX public."gestion_stock_colis_fk_ZoneDepot_id_8b581af3";
DROP INDEX public."gestion_stock_colis_fk_UniteManutentionSortie_id_4a8b42f0";
DROP INDEX public."gestion_stock_colis_fk_UniteManutentionEntree_id_16c75c12";
DROP INDEX public."gestion_stock_colis_fk_LitigeDecision_id_75ff08bd";
DROP INDEX public."gestion_stock_colis_fk_Article_id_4aa25755";
DROP INDEX public."gestion_stock_client_fk_TypeZone_id_a48ba631";
DROP INDEX public."gestion_stock_client_fk_TypeFournisseur_id_0cbea6bf";
DROP INDEX public."gestion_stock_client_fk_TypeDestinataire_id_d5074d84";
DROP INDEX public."gestion_stock_client_fk_TypeArticle_id_1af52016";
DROP INDEX public."gestion_stock_bonlivraisonentree_fk_TypeZoneDepot_id_e0d5dce3";
DROP INDEX public."gestion_stock_bonlivraisonentree_fk_Fournisseur_id_a14cc499";
DROP INDEX public."gestion_stock_bonlivraisonentree_fk_Destinataire_id_0b3e4c09";
DROP INDEX public."gestion_stock_bonlivraisonentree_fk_Client_id_17e7f6cb";
DROP INDEX public."gestion_stock_bonlivraison_fk_ZoneDepot_pour_TypeZone_ad6ef601";
DROP INDEX public."gestion_stock_bonlivraison_fk_LettreVoitureSortie_id_d498587e";
DROP INDEX public."gestion_stock_bonlivraison_fk_LettreVoitureEntree_id_bd1beab9";
DROP INDEX public."gestion_stock_bonlivraison_fk_BonCommandeSortie_id_312cf0b1";
DROP INDEX public."gestion_stock_boncommandesortie_fk_Transporteur_id_6d260680";
DROP INDEX public."gestion_stock_boncommandesortie_fk_Destinataire_id_3ca2e851";
DROP INDEX public."gestion_stock_boncommandesortie_fk_Client_id_d89f031e";
DROP INDEX public."gestion_stock_article_hist_fk_Fournisseur_id_26a4d479";
DROP INDEX public."gestion_stock_article_hist_fk_Article_id_cc2ae50c";
DROP INDEX public."gestion_stock_article_fk_TypeArticle_id_df0d768b";
DROP INDEX public."gestion_stock_article_fk_Fournisseur_id_af746084";
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_expire_date_a5c62663;
DROP INDEX public.django_admin_log_user_id_c564eba6;
DROP INDEX public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX public.auth_user_username_6821ab7c_like;
DROP INDEX public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX public.auth_user_groups_group_id_97559544;
DROP INDEX public.auth_permission_content_type_id_2f476e4b;
DROP INDEX public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.gestion_stock_zonedepot_pour_typezonedepot DROP CONSTRAINT gestion_stock_zonedepot_pour_typezonedepot_pkey;
ALTER TABLE ONLY public.gestion_stock_unitemanutentionsortie DROP CONSTRAINT gestion_stock_unitemanutentionsortie_pkey;
ALTER TABLE ONLY public.gestion_stock_unitemanutentionentree DROP CONSTRAINT gestion_stock_unitemanutentionentree_pkey;
ALTER TABLE ONLY public.gestion_stock_typezonedepot DROP CONSTRAINT gestion_stock_typezonedepot_pkey;
ALTER TABLE ONLY public.gestion_stock_typefournisseur_pour_fournisseur DROP CONSTRAINT gestion_stock_typefournisseur_pour_fournisseur_pkey;
ALTER TABLE ONLY public.gestion_stock_typedestinataire_pour_destinataire DROP CONSTRAINT gestion_stock_typedestinataire_pour_destinataire_pkey;
ALTER TABLE ONLY public.gestion_stock_typeboncommandesortie_pour_boncommandesortie DROP CONSTRAINT gestion_stock_typeboncommandesortie_pour_boncommandesortie_pkey;
ALTER TABLE ONLY public.gestion_stock_typearticle_pour_article DROP CONSTRAINT gestion_stock_typearticle_pour_article_pkey;
ALTER TABLE ONLY public.gestion_stock_transporteur DROP CONSTRAINT gestion_stock_transporteur_pkey;
ALTER TABLE ONLY public.gestion_stock_rolecontact_pour_client DROP CONSTRAINT gestion_stock_rolecontact_pour_client_pkey;
ALTER TABLE ONLY public.gestion_stock_pays_pour_destinataire DROP CONSTRAINT gestion_stock_pays_pour_destinataire_pkey;
ALTER TABLE ONLY public.gestion_stock_menuimages DROP CONSTRAINT gestion_stock_menuimages_pkey;
ALTER TABLE ONLY public.gestion_stock_litigedecision DROP CONSTRAINT gestion_stock_litigedecision_pkey;
ALTER TABLE ONLY public.gestion_stock_litige DROP CONSTRAINT gestion_stock_litige_pour_colis_pkey;
ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie DROP CONSTRAINT gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsor_pkey;
ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree DROP CONSTRAINT gestion_stock_lignebonlivraisonentree_pour_bonlivraisonent_pkey;
ALTER TABLE ONLY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie DROP CONSTRAINT gestion_stock_ligneboncommandesortie_pour_import_boncomman_pkey;
ALTER TABLE ONLY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree DROP CONSTRAINT gestion_stock_ligneboncommandeentree_pour_boncommandeentre_pkey;
ALTER TABLE ONLY public.gestion_stock_lettrevoituresortie DROP CONSTRAINT gestion_stock_lettrevoituresortie_pkey;
ALTER TABLE ONLY public.gestion_stock_lettrevoitureentree DROP CONSTRAINT gestion_stock_lettrevoitureentree_pkey;
ALTER TABLE ONLY public.gestion_stock_fournisseur DROP CONSTRAINT gestion_stock_fournisseur_pkey;
ALTER TABLE ONLY public.gestion_stock_destinataire DROP CONSTRAINT gestion_stock_destinataire_pkey;
ALTER TABLE ONLY public.gestion_stock_contact_pour_client DROP CONSTRAINT gestion_stock_contact_pour_client_pkey;
ALTER TABLE ONLY public.gestion_stock_colis DROP CONSTRAINT gestion_stock_colis_pkey;
ALTER TABLE ONLY public.gestion_stock_client DROP CONSTRAINT gestion_stock_client_pkey;
ALTER TABLE ONLY public.gestion_stock_bonlivraisonsortie DROP CONSTRAINT gestion_stock_bonlivraisonsortie_pkey;
ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree DROP CONSTRAINT gestion_stock_bonlivraisonentree_pkey;
ALTER TABLE ONLY public.gestion_stock_boncommandesortie DROP CONSTRAINT gestion_stock_boncommandesortie_pkey;
ALTER TABLE ONLY public.gestion_stock_boncommandeentree DROP CONSTRAINT gestion_stock_boncommandeentree_pkey;
ALTER TABLE ONLY public.gestion_stock_article DROP CONSTRAINT gestion_stock_article_pkey;
ALTER TABLE ONLY public.gestion_stock_article_historique_pour_article DROP CONSTRAINT gestion_stock_article_historique_pour_article_pkey;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.gestion_stock_zonedepot_pour_typezonedepot ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_unitemanutentionsortie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_unitemanutentionentree ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_typezonedepot ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_typefournisseur_pour_fournisseur ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_typedestinataire_pour_destinataire ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_typeboncommandesortie_pour_boncommandesortie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_typearticle_pour_article ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_transporteur ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_rolecontact_pour_client ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_pays_pour_destinataire ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_menuimages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_litigedecision ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_litige ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_lettrevoituresortie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_lettrevoitureentree ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_fournisseur ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_destinataire ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_contact_pour_client ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_colis ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_client ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_bonlivraisonsortie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_bonlivraisonentree ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_boncommandesortie ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_boncommandeentree ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_article_historique_pour_article ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.gestion_stock_article ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.gestion_stock_zonedepot_pour_typezonedepot_id_seq;
DROP TABLE public.gestion_stock_zonedepot_pour_typezonedepot;
DROP SEQUENCE public.gestion_stock_unitemanutentionsortie_id_seq;
DROP TABLE public.gestion_stock_unitemanutentionsortie;
DROP SEQUENCE public.gestion_stock_unitemanutentionentree_id_seq;
DROP TABLE public.gestion_stock_unitemanutentionentree;
DROP SEQUENCE public.gestion_stock_typezonedepot_id_seq;
DROP TABLE public.gestion_stock_typezonedepot;
DROP SEQUENCE public.gestion_stock_typefournisseur_pour_fournisseur_id_seq;
DROP TABLE public.gestion_stock_typefournisseur_pour_fournisseur;
DROP SEQUENCE public.gestion_stock_typedestinataire_pour_destinataire_id_seq;
DROP TABLE public.gestion_stock_typedestinataire_pour_destinataire;
DROP SEQUENCE public.gestion_stock_typeboncommandesortie_pour_boncommandesort_id_seq;
DROP TABLE public.gestion_stock_typeboncommandesortie_pour_boncommandesortie;
DROP SEQUENCE public.gestion_stock_typearticle_pour_article_id_seq;
DROP TABLE public.gestion_stock_typearticle_pour_article;
DROP SEQUENCE public.gestion_stock_transporteur_id_seq;
DROP TABLE public.gestion_stock_transporteur;
DROP SEQUENCE public.gestion_stock_rolecontact_pour_client_id_seq;
DROP TABLE public.gestion_stock_rolecontact_pour_client;
DROP SEQUENCE public.gestion_stock_pays_pour_destinataire_id_seq;
DROP TABLE public.gestion_stock_pays_pour_destinataire;
DROP SEQUENCE public.gestion_stock_menuimages_id_seq;
DROP TABLE public.gestion_stock_menuimages;
DROP SEQUENCE public.gestion_stock_litigedecision_id_seq;
DROP TABLE public.gestion_stock_litigedecision;
DROP SEQUENCE public.gestion_stock_litige_pour_colis_id_seq;
DROP TABLE public.gestion_stock_litige;
DROP SEQUENCE public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisons_id_seq;
DROP TABLE public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie;
DROP SEQUENCE public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisone_id_seq;
DROP TABLE public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree;
DROP SEQUENCE public.gestion_stock_ligneboncommandesortie_pour_import_boncomm_id_seq;
DROP TABLE public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie;
DROP SEQUENCE public.gestion_stock_ligneboncommandeentree_pour_boncommandeent_id_seq;
DROP TABLE public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree;
DROP SEQUENCE public.gestion_stock_lettrevoituresortie_id_seq;
DROP TABLE public.gestion_stock_lettrevoituresortie;
DROP SEQUENCE public.gestion_stock_lettrevoitureentree_id_seq;
DROP TABLE public.gestion_stock_lettrevoitureentree;
DROP SEQUENCE public.gestion_stock_fournisseur_id_seq;
DROP TABLE public.gestion_stock_fournisseur;
DROP SEQUENCE public.gestion_stock_destinataire_id_seq;
DROP TABLE public.gestion_stock_destinataire;
DROP SEQUENCE public.gestion_stock_contact_pour_client_id_seq;
DROP TABLE public.gestion_stock_contact_pour_client;
DROP SEQUENCE public.gestion_stock_colis_id_seq;
DROP TABLE public.gestion_stock_colis;
DROP SEQUENCE public.gestion_stock_client_id_seq;
DROP TABLE public.gestion_stock_client;
DROP SEQUENCE public.gestion_stock_bonlivraisonsortie_id_seq;
DROP TABLE public.gestion_stock_bonlivraisonsortie;
DROP SEQUENCE public.gestion_stock_bonlivraisonentree_id_seq;
DROP TABLE public.gestion_stock_bonlivraisonentree;
DROP SEQUENCE public.gestion_stock_boncommandesortie_id_seq;
DROP TABLE public.gestion_stock_boncommandesortie;
DROP SEQUENCE public.gestion_stock_boncommandeentree_id_seq;
DROP TABLE public.gestion_stock_boncommandeentree;
DROP SEQUENCE public.gestion_stock_article_id_seq;
DROP SEQUENCE public.gestion_stock_article_historique_pour_article_id_seq;
DROP TABLE public.gestion_stock_article_historique_pour_article;
DROP TABLE public.gestion_stock_article;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO admin;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO admin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO admin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO admin;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO admin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO admin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO admin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO admin;

--
-- Name: gestion_stock_article; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_article (
    id integer NOT NULL,
    "idArticle" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    "codeFournisseur" character varying(150) NOT NULL,
    "codeClient" character varying(150) NOT NULL,
    "designationFournisseur" character varying(150) NOT NULL,
    "designationClient" character varying(150) NOT NULL,
    "dureeStockage" character varying(150) NOT NULL,
    "delaiPeremption" character varying(150) NOT NULL,
    stock character varying(150) NOT NULL,
    "poidsColisStandard" character varying(150) NOT NULL,
    "quantiteColisStandard" character varying(150) NOT NULL,
    "quantiteColisStockComplet" character varying(150) NOT NULL,
    "quantiteProduitStockComplet" character varying(150) NOT NULL,
    "quantiteColisStockIncomplet" character varying(150) NOT NULL,
    "quantiteProduitStockIncomplet" character varying(150) NOT NULL,
    "quantiteUniteManutentionSortie" character varying(150) NOT NULL,
    source character varying(150) NOT NULL,
    "identifiantSource" character varying(150) NOT NULL,
    "fk_Fournisseur_id" integer,
    "fk_TypeArticle_id" integer NOT NULL
);


ALTER TABLE public.gestion_stock_article OWNER TO admin;

--
-- Name: gestion_stock_article_historique_pour_article; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_article_historique_pour_article (
    id integer NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    "idArticle_historique" character varying(150) NOT NULL,
    "nomFournisseur" character varying(150) NOT NULL,
    "codeFournisseur" character varying(150) NOT NULL,
    "designationFournisseur" character varying(150) NOT NULL,
    "codeClient" character varying(150) NOT NULL,
    "designationClient" character varying(150) NOT NULL,
    poids character varying(150) NOT NULL,
    "delaiPeremption" character varying(150) NOT NULL,
    "dureeStockage" character varying(150) NOT NULL,
    "fk_Article_id" integer NOT NULL,
    "fk_Fournisseur_id" integer NOT NULL
);


ALTER TABLE public.gestion_stock_article_historique_pour_article OWNER TO admin;

--
-- Name: gestion_stock_article_historique_pour_article_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_article_historique_pour_article_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_article_historique_pour_article_id_seq OWNER TO admin;

--
-- Name: gestion_stock_article_historique_pour_article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_article_historique_pour_article_id_seq OWNED BY public.gestion_stock_article_historique_pour_article.id;


--
-- Name: gestion_stock_article_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_article_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_article_id_seq OWNER TO admin;

--
-- Name: gestion_stock_article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_article_id_seq OWNED BY public.gestion_stock_article.id;


--
-- Name: gestion_stock_boncommandeentree; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_boncommandeentree (
    id integer NOT NULL,
    "idBonCommandeEntree" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    "dateCommande" character varying(150) NOT NULL,
    "numeroCommande" character varying(150) NOT NULL,
    source character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_boncommandeentree OWNER TO admin;

--
-- Name: gestion_stock_boncommandeentree_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_boncommandeentree_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_boncommandeentree_id_seq OWNER TO admin;

--
-- Name: gestion_stock_boncommandeentree_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_boncommandeentree_id_seq OWNED BY public.gestion_stock_boncommandeentree.id;


--
-- Name: gestion_stock_boncommandesortie; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_boncommandesortie (
    id integer NOT NULL,
    "idBonCommandeSortie" character varying(150) NOT NULL,
    termine character varying(150) NOT NULL,
    source character varying(150) NOT NULL,
    "identifiantSource" character varying(150) NOT NULL,
    "numeroCommande" character varying(150) NOT NULL,
    "dateCommande" character varying(150) NOT NULL,
    "fk_Client_id" integer,
    "fk_Destinataire_id" integer,
    "fk_Transporteur_id" integer
);


ALTER TABLE public.gestion_stock_boncommandesortie OWNER TO admin;

--
-- Name: gestion_stock_boncommandesortie_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_boncommandesortie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_boncommandesortie_id_seq OWNER TO admin;

--
-- Name: gestion_stock_boncommandesortie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_boncommandesortie_id_seq OWNED BY public.gestion_stock_boncommandesortie.id;


--
-- Name: gestion_stock_bonlivraisonentree; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_bonlivraisonentree (
    id integer NOT NULL,
    "idBonLivraisonEntree" character varying(150) NOT NULL,
    "dateReception" character varying(150) NOT NULL,
    "numeroBonLivraison" character varying(150) NOT NULL,
    "quantitePalette" character varying(150) NOT NULL,
    commentaire character varying(150) NOT NULL,
    "fk_Client_id" integer,
    "fk_Fournisseur_id" integer,
    "fk_TypeZoneDepot_id" integer,
    "fk_LettreVoitureEntree_id" integer,
    "fk_Destinataire_id" integer,
    "fk_ZoneDepot_pour_TypeZoneDepot_id" integer
);


ALTER TABLE public.gestion_stock_bonlivraisonentree OWNER TO admin;

--
-- Name: gestion_stock_bonlivraisonentree_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_bonlivraisonentree_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_bonlivraisonentree_id_seq OWNER TO admin;

--
-- Name: gestion_stock_bonlivraisonentree_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_bonlivraisonentree_id_seq OWNED BY public.gestion_stock_bonlivraisonentree.id;


--
-- Name: gestion_stock_bonlivraisonsortie; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_bonlivraisonsortie (
    id integer NOT NULL,
    "idBonLivraisonSortie" character varying(150) NOT NULL,
    "dateImpression" character varying(150) NOT NULL,
    "numeroBonLivraison" character varying(150) NOT NULL,
    "prixExpedition" character varying(150) NOT NULL,
    "codeTracking" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    "fk_BonCommandeSortie_id" integer NOT NULL,
    "fk_LettreVoitureSortie_id" integer NOT NULL
);


ALTER TABLE public.gestion_stock_bonlivraisonsortie OWNER TO admin;

--
-- Name: gestion_stock_bonlivraisonsortie_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_bonlivraisonsortie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_bonlivraisonsortie_id_seq OWNER TO admin;

--
-- Name: gestion_stock_bonlivraisonsortie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_bonlivraisonsortie_id_seq OWNED BY public.gestion_stock_bonlivraisonsortie.id;


--
-- Name: gestion_stock_client; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_client (
    id integer NOT NULL,
    "idClient" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    nom character varying(150) NOT NULL,
    adresse character varying(150) NOT NULL,
    commentaire character varying(150) NOT NULL,
    telephone character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    siret character varying(150) NOT NULL,
    tva character varying(150) NOT NULL,
    source character varying(150) NOT NULL,
    "identifiantSource" character varying(150) NOT NULL,
    "nomCompte" character varying(150) NOT NULL,
    "fk_TypeArticle_id" integer,
    "fk_TypeDestinataire_id" integer,
    "fk_TypeFournisseur_id" integer,
    "fk_TypeZone_id" integer
);


ALTER TABLE public.gestion_stock_client OWNER TO admin;

--
-- Name: gestion_stock_client_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_client_id_seq OWNER TO admin;

--
-- Name: gestion_stock_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_client_id_seq OWNED BY public.gestion_stock_client.id;


--
-- Name: gestion_stock_colis; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_colis (
    id integer NOT NULL,
    "idColis" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    "datePeremption" character varying(150) NOT NULL,
    "emplacementConfirme" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    "numeroLot" character varying(150) NOT NULL,
    numerotation character varying(150) NOT NULL,
    "quantiteProduit" character varying(150) NOT NULL,
    fk_litige_id integer,
    "fk_Article_id" integer,
    "fk_UniteManutentionEntree_id" integer,
    "fk_UniteManutentionSortie_id" integer,
    "fk_LitigeDecision_id" integer,
    "fk_ZoneDepot_id" integer,
    colle character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_colis OWNER TO admin;

--
-- Name: gestion_stock_colis_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_colis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_colis_id_seq OWNER TO admin;

--
-- Name: gestion_stock_colis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_colis_id_seq OWNED BY public.gestion_stock_colis.id;


--
-- Name: gestion_stock_contact_pour_client; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_contact_pour_client (
    id integer NOT NULL,
    "fk_Client_id" integer NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    "idContact" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    nom character varying(150) NOT NULL,
    prenom character varying(150) NOT NULL,
    telephone character varying(150) NOT NULL,
    "fk_RoleContact_id" integer
);


ALTER TABLE public.gestion_stock_contact_pour_client OWNER TO admin;

--
-- Name: gestion_stock_contact_pour_client_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_contact_pour_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_contact_pour_client_id_seq OWNER TO admin;

--
-- Name: gestion_stock_contact_pour_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_contact_pour_client_id_seq OWNED BY public.gestion_stock_contact_pour_client.id;


--
-- Name: gestion_stock_destinataire; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_destinataire (
    id integer NOT NULL,
    "idDestinataire" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    "adresseLivraison" character varying(150) NOT NULL,
    "adresseFacturation" character varying(150) NOT NULL,
    departement character varying(150) NOT NULL,
    telephone character varying(150) NOT NULL,
    nom character varying(150) NOT NULL,
    "identifiantBonLivraison" character varying(150) NOT NULL,
    commentaire character varying(150) NOT NULL,
    "codeUM" character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    source character varying(150) NOT NULL,
    "identifiantSource" character varying(150) NOT NULL,
    "adresseLivraison_nom" character varying(150) NOT NULL,
    "adresseLivraison_numero" character varying(150) NOT NULL,
    "adresseLivraison_rue" character varying(150) NOT NULL,
    "adresseLivraison_complement_1" character varying(150) NOT NULL,
    "adresseLivraison_complement_2" character varying(150) NOT NULL,
    "adresseLivraison_codePostal" character varying(150) NOT NULL,
    "adresseLivraison_localite" character varying(150) NOT NULL,
    "delaiPeremption" character varying(150) NOT NULL,
    "ordreTri" character varying(150) NOT NULL,
    "fk_Pays_id" integer NOT NULL,
    "fk_TypeDestinataire_id" integer NOT NULL
);


ALTER TABLE public.gestion_stock_destinataire OWNER TO admin;

--
-- Name: gestion_stock_destinataire_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_destinataire_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_destinataire_id_seq OWNER TO admin;

--
-- Name: gestion_stock_destinataire_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_destinataire_id_seq OWNED BY public.gestion_stock_destinataire.id;


--
-- Name: gestion_stock_fournisseur; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_fournisseur (
    id integer NOT NULL,
    "idFournisseur" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    nom character varying(150) NOT NULL,
    source character varying(150) NOT NULL,
    "identifiantSource" character varying(150) NOT NULL,
    "fk_TypeFournisseur_id" integer
);


ALTER TABLE public.gestion_stock_fournisseur OWNER TO admin;

--
-- Name: gestion_stock_fournisseur_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_fournisseur_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_fournisseur_id_seq OWNER TO admin;

--
-- Name: gestion_stock_fournisseur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_fournisseur_id_seq OWNED BY public.gestion_stock_fournisseur.id;


--
-- Name: gestion_stock_lettrevoitureentree; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_lettrevoitureentree (
    id integer NOT NULL,
    "idLettreVoitureEntree" character varying(150) NOT NULL,
    "fk_Transporteur_id" integer,
    datereception character varying(150) NOT NULL,
    numerorecepisse character varying(150) NOT NULL,
    quantitecolis character varying(150) NOT NULL,
    quantitepalette character varying(150) NOT NULL,
    reclacomm character varying(150) NOT NULL,
    reclaquantitecolis character varying(150) NOT NULL,
    reclaquantitepalette character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_lettrevoitureentree OWNER TO admin;

--
-- Name: gestion_stock_lettrevoitureentree_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_lettrevoitureentree_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_lettrevoitureentree_id_seq OWNER TO admin;

--
-- Name: gestion_stock_lettrevoitureentree_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_lettrevoitureentree_id_seq OWNED BY public.gestion_stock_lettrevoitureentree.id;


--
-- Name: gestion_stock_lettrevoituresortie; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_lettrevoituresortie (
    id integer NOT NULL,
    "idLettreVoitureSortie" character varying(150) NOT NULL,
    datereception character varying(150) NOT NULL,
    numerorecepisse character varying(150) NOT NULL,
    quantitepalette character varying(150) NOT NULL,
    quantitecolis character varying(150) NOT NULL,
    reclaquantitepalette character varying(150) NOT NULL,
    reclaquantitecolis character varying(150) NOT NULL,
    reclacomm character varying(150) NOT NULL,
    "fk_Transporteur_id" integer
);


ALTER TABLE public.gestion_stock_lettrevoituresortie OWNER TO admin;

--
-- Name: gestion_stock_lettrevoituresortie_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_lettrevoituresortie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_lettrevoituresortie_id_seq OWNER TO admin;

--
-- Name: gestion_stock_lettrevoituresortie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_lettrevoituresortie_id_seq OWNED BY public.gestion_stock_lettrevoituresortie.id;


--
-- Name: gestion_stock_ligneboncommandeentree_pour_boncommandeentree; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree (
    id integer NOT NULL,
    "fk_Article_id" integer NOT NULL,
    "fk_BonCommandeEntree_id" integer NOT NULL,
    "dateLivraison" character varying(150) NOT NULL,
    "idLigneBonCommandeEntree" character varying(150) NOT NULL,
    "identifiantSource" character varying(150) NOT NULL,
    "quantiteColis" character varying(150) NOT NULL,
    "quantiteProduit" character varying(150) NOT NULL,
    "quantiteRecue" character varying(150) NOT NULL,
    source character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree OWNER TO admin;

--
-- Name: gestion_stock_ligneboncommandeentree_pour_boncommandeent_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_ligneboncommandeentree_pour_boncommandeent_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_ligneboncommandeentree_pour_boncommandeent_id_seq OWNER TO admin;

--
-- Name: gestion_stock_ligneboncommandeentree_pour_boncommandeent_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_ligneboncommandeentree_pour_boncommandeent_id_seq OWNED BY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree.id;


--
-- Name: gestion_stock_ligneboncommandesortie_pour_boncommandesortie; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie (
    id integer NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    "idLigneBonCommandeSortie" character varying(150) NOT NULL,
    "quantiteProduitCommande" character varying(150) NOT NULL,
    "quantiteColisCommande" character varying(150) NOT NULL,
    "quantiteProduitALivrer" character varying(150) NOT NULL,
    "quantiteProduitLivre" character varying(150) NOT NULL,
    "quantiteColisLivre" character varying(150) NOT NULL,
    "quantiteProduitPotentielle" character varying(150) NOT NULL,
    "quantiteColisPotentielle" character varying(150) NOT NULL,
    "differenceCommandeLivre" character varying(150) NOT NULL,
    "differenceCommandePotentiel" character varying(150) NOT NULL,
    termine character varying(150) NOT NULL,
    priorite character varying(150) NOT NULL,
    source character varying(150) NOT NULL,
    "identifiantSource" character varying(150) NOT NULL,
    "fk_Article_id" integer NOT NULL,
    "fk_BonCommandeSortie_id" integer NOT NULL
);


ALTER TABLE public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie OWNER TO admin;

--
-- Name: gestion_stock_ligneboncommandesortie_pour_import_boncomm_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_ligneboncommandesortie_pour_import_boncomm_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_ligneboncommandesortie_pour_import_boncomm_id_seq OWNER TO admin;

--
-- Name: gestion_stock_ligneboncommandesortie_pour_import_boncomm_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_ligneboncommandesortie_pour_import_boncomm_id_seq OWNED BY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie.id;


--
-- Name: gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree (
    id integer NOT NULL,
    "idLigneBonLivraisonEntree" character varying(150) NOT NULL,
    controle character varying(150) NOT NULL,
    "quantiteColis" character varying(150) NOT NULL,
    "quantiteColisAlivrer" character varying(150) NOT NULL,
    "quantiteColisLitige" character varying(150) NOT NULL,
    "quantiteColisRecu" character varying(150) NOT NULL,
    "quantiteCommande" character varying(150) NOT NULL,
    "quantiteCommandeRecue" character varying(150) NOT NULL,
    "quantiteDifference" character varying(150) NOT NULL,
    "quantiteDifferenceAutre" character varying(150) NOT NULL,
    "quantiteDifferenceRestante" character varying(150) NOT NULL,
    "quantiteProduit" character varying(150) NOT NULL,
    "quantiteProduitAlivrer" character varying(150) NOT NULL,
    "quantiteProduitLitige" character varying(150) NOT NULL,
    "quantiteProduitRecu" character varying(150) NOT NULL,
    termine character varying(150) NOT NULL,
    "fk_Article_id" integer,
    "fk_BonLivraisonEntree_id" integer
);


ALTER TABLE public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree OWNER TO admin;

--
-- Name: gestion_stock_lignebonlivraisonentree_pour_bonlivraisone_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisone_id_seq OWNER TO admin;

--
-- Name: gestion_stock_lignebonlivraisonentree_pour_bonlivraisone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisone_id_seq OWNED BY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree.id;


--
-- Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie (
    id integer NOT NULL,
    "idLigneBonLivraisonSortie" character varying(150) NOT NULL,
    "quantiteColis" character varying(150) NOT NULL,
    "stat_quantiteColis" character varying(150) NOT NULL,
    "fk_Article_id" integer NOT NULL,
    "fk_BonLivraisonSortie_id" integer NOT NULL,
    "fk_Transporteur_id" integer NOT NULL
);


ALTER TABLE public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie OWNER TO admin;

--
-- Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisons_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisons_id_seq OWNER TO admin;

--
-- Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisons_id_seq OWNED BY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie.id;


--
-- Name: gestion_stock_litige; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_litige (
    id integer NOT NULL,
    "idLitige" character varying(150) NOT NULL,
    nom character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_litige OWNER TO admin;

--
-- Name: gestion_stock_litige_pour_colis_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_litige_pour_colis_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_litige_pour_colis_id_seq OWNER TO admin;

--
-- Name: gestion_stock_litige_pour_colis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_litige_pour_colis_id_seq OWNED BY public.gestion_stock_litige.id;


--
-- Name: gestion_stock_litigedecision; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_litigedecision (
    id integer NOT NULL,
    "idLitige" character varying(150) NOT NULL,
    nom character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_litigedecision OWNER TO admin;

--
-- Name: gestion_stock_litigedecision_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_litigedecision_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_litigedecision_id_seq OWNER TO admin;

--
-- Name: gestion_stock_litigedecision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_litigedecision_id_seq OWNED BY public.gestion_stock_litigedecision.id;


--
-- Name: gestion_stock_menuimages; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_menuimages (
    id integer NOT NULL,
    title text NOT NULL,
    cover1 character varying(100) NOT NULL,
    cover2 character varying(100) NOT NULL,
    cover3 character varying(100) NOT NULL,
    cover4 character varying(100) NOT NULL,
    cover5 character varying(100) NOT NULL,
    cover6 character varying(100) NOT NULL,
    cover7 character varying(100) NOT NULL,
    cover8 character varying(100) NOT NULL,
    cover9 character varying(100) NOT NULL,
    cover10 character varying(100) NOT NULL,
    cover11 character varying(100) NOT NULL,
    cover12 character varying(100) NOT NULL,
    cover13 character varying(100) NOT NULL,
    cover14 character varying(100) NOT NULL
);


ALTER TABLE public.gestion_stock_menuimages OWNER TO admin;

--
-- Name: gestion_stock_menuimages_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_menuimages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_menuimages_id_seq OWNER TO admin;

--
-- Name: gestion_stock_menuimages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_menuimages_id_seq OWNED BY public.gestion_stock_menuimages.id;


--
-- Name: gestion_stock_pays_pour_destinataire; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_pays_pour_destinataire (
    id integer NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    "idPays" character varying(150) NOT NULL,
    nom character varying(150) NOT NULL,
    "codeISO_2" character varying(150) NOT NULL,
    "codeISO_3" character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_pays_pour_destinataire OWNER TO admin;

--
-- Name: gestion_stock_pays_pour_destinataire_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_pays_pour_destinataire_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_pays_pour_destinataire_id_seq OWNER TO admin;

--
-- Name: gestion_stock_pays_pour_destinataire_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_pays_pour_destinataire_id_seq OWNED BY public.gestion_stock_pays_pour_destinataire.id;


--
-- Name: gestion_stock_rolecontact_pour_client; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_rolecontact_pour_client (
    id integer NOT NULL,
    "idRoleContact" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    nom character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_rolecontact_pour_client OWNER TO admin;

--
-- Name: gestion_stock_rolecontact_pour_client_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_rolecontact_pour_client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_rolecontact_pour_client_id_seq OWNER TO admin;

--
-- Name: gestion_stock_rolecontact_pour_client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_rolecontact_pour_client_id_seq OWNED BY public.gestion_stock_rolecontact_pour_client.id;


--
-- Name: gestion_stock_transporteur; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_transporteur (
    id integer NOT NULL,
    "idTransporteur" character varying(150) NOT NULL,
    nom character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_transporteur OWNER TO admin;

--
-- Name: gestion_stock_transporteur_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_transporteur_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_transporteur_id_seq OWNER TO admin;

--
-- Name: gestion_stock_transporteur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_transporteur_id_seq OWNED BY public.gestion_stock_transporteur.id;


--
-- Name: gestion_stock_typearticle_pour_article; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_typearticle_pour_article (
    id integer NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    "idTypeArticle" character varying(150) NOT NULL,
    nom character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_typearticle_pour_article OWNER TO admin;

--
-- Name: gestion_stock_typearticle_pour_article_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_typearticle_pour_article_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_typearticle_pour_article_id_seq OWNER TO admin;

--
-- Name: gestion_stock_typearticle_pour_article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_typearticle_pour_article_id_seq OWNED BY public.gestion_stock_typearticle_pour_article.id;


--
-- Name: gestion_stock_typeboncommandesortie_pour_boncommandesortie; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_typeboncommandesortie_pour_boncommandesortie (
    id integer NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    "idTypeBonCommandeSortie" character varying(150) NOT NULL,
    nom character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_typeboncommandesortie_pour_boncommandesortie OWNER TO admin;

--
-- Name: gestion_stock_typeboncommandesortie_pour_boncommandesort_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_typeboncommandesortie_pour_boncommandesort_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_typeboncommandesortie_pour_boncommandesort_id_seq OWNER TO admin;

--
-- Name: gestion_stock_typeboncommandesortie_pour_boncommandesort_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_typeboncommandesortie_pour_boncommandesort_id_seq OWNED BY public.gestion_stock_typeboncommandesortie_pour_boncommandesortie.id;


--
-- Name: gestion_stock_typedestinataire_pour_destinataire; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_typedestinataire_pour_destinataire (
    id integer NOT NULL,
    "idTypeDestinataire" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    nom character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_typedestinataire_pour_destinataire OWNER TO admin;

--
-- Name: gestion_stock_typedestinataire_pour_destinataire_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_typedestinataire_pour_destinataire_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_typedestinataire_pour_destinataire_id_seq OWNER TO admin;

--
-- Name: gestion_stock_typedestinataire_pour_destinataire_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_typedestinataire_pour_destinataire_id_seq OWNED BY public.gestion_stock_typedestinataire_pour_destinataire.id;


--
-- Name: gestion_stock_typefournisseur_pour_fournisseur; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_typefournisseur_pour_fournisseur (
    id integer NOT NULL,
    "idTypeFournisseur" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    nom character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_typefournisseur_pour_fournisseur OWNER TO admin;

--
-- Name: gestion_stock_typefournisseur_pour_fournisseur_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_typefournisseur_pour_fournisseur_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_typefournisseur_pour_fournisseur_id_seq OWNER TO admin;

--
-- Name: gestion_stock_typefournisseur_pour_fournisseur_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_typefournisseur_pour_fournisseur_id_seq OWNED BY public.gestion_stock_typefournisseur_pour_fournisseur.id;


--
-- Name: gestion_stock_typezonedepot; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_typezonedepot (
    id integer NOT NULL,
    "idTypeZoneDepot" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    nom character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_typezonedepot OWNER TO admin;

--
-- Name: gestion_stock_typezonedepot_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_typezonedepot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_typezonedepot_id_seq OWNER TO admin;

--
-- Name: gestion_stock_typezonedepot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_typezonedepot_id_seq OWNED BY public.gestion_stock_typezonedepot.id;


--
-- Name: gestion_stock_unitemanutentionentree; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_unitemanutentionentree (
    id integer NOT NULL,
    "idUniteManutentionEntree" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    numero character varying(150) NOT NULL,
    "dateReception" character varying(150) NOT NULL,
    stock character varying(150) NOT NULL,
    "fk_BonLivraisonEntree_id" integer
);


ALTER TABLE public.gestion_stock_unitemanutentionentree OWNER TO admin;

--
-- Name: gestion_stock_unitemanutentionentree_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_unitemanutentionentree_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_unitemanutentionentree_id_seq OWNER TO admin;

--
-- Name: gestion_stock_unitemanutentionentree_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_unitemanutentionentree_id_seq OWNED BY public.gestion_stock_unitemanutentionentree.id;


--
-- Name: gestion_stock_unitemanutentionsortie; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_unitemanutentionsortie (
    id integer NOT NULL,
    "idUniteManutentionSortie" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    numero character varying(150) NOT NULL,
    "dateReception" character varying(150) NOT NULL,
    "fk_BonCommandeSortie_id" integer,
    "fk_BonLivraisonSortie_id" integer,
    "poidsBrut" character varying(150) NOT NULL,
    "poidsDifference" character varying(150) NOT NULL,
    "poidsNet" character varying(150) NOT NULL,
    "poidsTare" character varying(150) NOT NULL,
    "dateExpedition" character varying(150) NOT NULL,
    "dateOuverture" character varying(150) NOT NULL
);


ALTER TABLE public.gestion_stock_unitemanutentionsortie OWNER TO admin;

--
-- Name: gestion_stock_unitemanutentionsortie_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_unitemanutentionsortie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_unitemanutentionsortie_id_seq OWNER TO admin;

--
-- Name: gestion_stock_unitemanutentionsortie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_unitemanutentionsortie_id_seq OWNED BY public.gestion_stock_unitemanutentionsortie.id;


--
-- Name: gestion_stock_zonedepot_pour_typezonedepot; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.gestion_stock_zonedepot_pour_typezonedepot (
    id integer NOT NULL,
    "idZoneDepot" character varying(150) NOT NULL,
    c_nom character varying(150) NOT NULL,
    "c_nomCompte" character varying(150) NOT NULL,
    c_horodatage character varying(150) NOT NULL,
    m_nom character varying(150) NOT NULL,
    "m_nomCompte" character varying(150) NOT NULL,
    m_horodatage character varying(150) NOT NULL,
    nom character varying(150) NOT NULL,
    "fk_TypeZoneDepot_id" integer
);


ALTER TABLE public.gestion_stock_zonedepot_pour_typezonedepot OWNER TO admin;

--
-- Name: gestion_stock_zonedepot_pour_typezonedepot_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.gestion_stock_zonedepot_pour_typezonedepot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_stock_zonedepot_pour_typezonedepot_id_seq OWNER TO admin;

--
-- Name: gestion_stock_zonedepot_pour_typezonedepot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.gestion_stock_zonedepot_pour_typezonedepot_id_seq OWNED BY public.gestion_stock_zonedepot_pour_typezonedepot.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: gestion_stock_article id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_article ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_article_id_seq'::regclass);


--
-- Name: gestion_stock_article_historique_pour_article id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_article_historique_pour_article ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_article_historique_pour_article_id_seq'::regclass);


--
-- Name: gestion_stock_boncommandeentree id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_boncommandeentree ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_boncommandeentree_id_seq'::regclass);


--
-- Name: gestion_stock_boncommandesortie id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_boncommandesortie ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_boncommandesortie_id_seq'::regclass);


--
-- Name: gestion_stock_bonlivraisonentree id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_bonlivraisonentree_id_seq'::regclass);


--
-- Name: gestion_stock_bonlivraisonsortie id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonsortie ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_bonlivraisonsortie_id_seq'::regclass);


--
-- Name: gestion_stock_client id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_client ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_client_id_seq'::regclass);


--
-- Name: gestion_stock_colis id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_colis ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_colis_id_seq'::regclass);


--
-- Name: gestion_stock_contact_pour_client id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_contact_pour_client ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_contact_pour_client_id_seq'::regclass);


--
-- Name: gestion_stock_destinataire id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_destinataire ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_destinataire_id_seq'::regclass);


--
-- Name: gestion_stock_fournisseur id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_fournisseur ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_fournisseur_id_seq'::regclass);


--
-- Name: gestion_stock_lettrevoitureentree id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lettrevoitureentree ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_lettrevoitureentree_id_seq'::regclass);


--
-- Name: gestion_stock_lettrevoituresortie id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lettrevoituresortie ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_lettrevoituresortie_id_seq'::regclass);


--
-- Name: gestion_stock_ligneboncommandeentree_pour_boncommandeentree id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_ligneboncommandeentree_pour_boncommandeent_id_seq'::regclass);


--
-- Name: gestion_stock_ligneboncommandesortie_pour_boncommandesortie id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_ligneboncommandesortie_pour_import_boncomm_id_seq'::regclass);


--
-- Name: gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisone_id_seq'::regclass);


--
-- Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisons_id_seq'::regclass);


--
-- Name: gestion_stock_litige id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_litige ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_litige_pour_colis_id_seq'::regclass);


--
-- Name: gestion_stock_litigedecision id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_litigedecision ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_litigedecision_id_seq'::regclass);


--
-- Name: gestion_stock_menuimages id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_menuimages ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_menuimages_id_seq'::regclass);


--
-- Name: gestion_stock_pays_pour_destinataire id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_pays_pour_destinataire ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_pays_pour_destinataire_id_seq'::regclass);


--
-- Name: gestion_stock_rolecontact_pour_client id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_rolecontact_pour_client ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_rolecontact_pour_client_id_seq'::regclass);


--
-- Name: gestion_stock_transporteur id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_transporteur ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_transporteur_id_seq'::regclass);


--
-- Name: gestion_stock_typearticle_pour_article id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typearticle_pour_article ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_typearticle_pour_article_id_seq'::regclass);


--
-- Name: gestion_stock_typeboncommandesortie_pour_boncommandesortie id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typeboncommandesortie_pour_boncommandesortie ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_typeboncommandesortie_pour_boncommandesort_id_seq'::regclass);


--
-- Name: gestion_stock_typedestinataire_pour_destinataire id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typedestinataire_pour_destinataire ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_typedestinataire_pour_destinataire_id_seq'::regclass);


--
-- Name: gestion_stock_typefournisseur_pour_fournisseur id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typefournisseur_pour_fournisseur ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_typefournisseur_pour_fournisseur_id_seq'::regclass);


--
-- Name: gestion_stock_typezonedepot id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typezonedepot ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_typezonedepot_id_seq'::regclass);


--
-- Name: gestion_stock_unitemanutentionentree id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_unitemanutentionentree ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_unitemanutentionentree_id_seq'::regclass);


--
-- Name: gestion_stock_unitemanutentionsortie id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_unitemanutentionsortie ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_unitemanutentionsortie_id_seq'::regclass);


--
-- Name: gestion_stock_zonedepot_pour_typezonedepot id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_zonedepot_pour_typezonedepot ALTER COLUMN id SET DEFAULT nextval('public.gestion_stock_zonedepot_pour_typezonedepot_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3310.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3312.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3314.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/3316.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/3317.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3320.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3322.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3324.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3326.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3328.dat';

--
-- Data for Name: gestion_stock_article; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_article (id, "idArticle", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "codeFournisseur", "codeClient", "designationFournisseur", "designationClient", "dureeStockage", "delaiPeremption", stock, "poidsColisStandard", "quantiteColisStandard", "quantiteColisStockComplet", "quantiteProduitStockComplet", "quantiteColisStockIncomplet", "quantiteProduitStockIncomplet", "quantiteUniteManutentionSortie", source, "identifiantSource", "fk_Fournisseur_id", "fk_TypeArticle_id") FROM stdin;
\.
COPY public.gestion_stock_article (id, "idArticle", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "codeFournisseur", "codeClient", "designationFournisseur", "designationClient", "dureeStockage", "delaiPeremption", stock, "poidsColisStandard", "quantiteColisStandard", "quantiteColisStockComplet", "quantiteProduitStockComplet", "quantiteColisStockIncomplet", "quantiteProduitStockIncomplet", "quantiteUniteManutentionSortie", source, "identifiantSource", "fk_Fournisseur_id", "fk_TypeArticle_id") FROM '$$PATH$$/3329.dat';

--
-- Data for Name: gestion_stock_article_historique_pour_article; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_article_historique_pour_article (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idArticle_historique", "nomFournisseur", "codeFournisseur", "designationFournisseur", "codeClient", "designationClient", poids, "delaiPeremption", "dureeStockage", "fk_Article_id", "fk_Fournisseur_id") FROM stdin;
\.
COPY public.gestion_stock_article_historique_pour_article (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idArticle_historique", "nomFournisseur", "codeFournisseur", "designationFournisseur", "codeClient", "designationClient", poids, "delaiPeremption", "dureeStockage", "fk_Article_id", "fk_Fournisseur_id") FROM '$$PATH$$/3330.dat';

--
-- Data for Name: gestion_stock_boncommandeentree; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_boncommandeentree (id, "idBonCommandeEntree", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "dateCommande", "numeroCommande", source) FROM stdin;
\.
COPY public.gestion_stock_boncommandeentree (id, "idBonCommandeEntree", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "dateCommande", "numeroCommande", source) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: gestion_stock_boncommandesortie; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_boncommandesortie (id, "idBonCommandeSortie", termine, source, "identifiantSource", "numeroCommande", "dateCommande", "fk_Client_id", "fk_Destinataire_id", "fk_Transporteur_id") FROM stdin;
\.
COPY public.gestion_stock_boncommandesortie (id, "idBonCommandeSortie", termine, source, "identifiantSource", "numeroCommande", "dateCommande", "fk_Client_id", "fk_Destinataire_id", "fk_Transporteur_id") FROM '$$PATH$$/3335.dat';

--
-- Data for Name: gestion_stock_bonlivraisonentree; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_bonlivraisonentree (id, "idBonLivraisonEntree", "dateReception", "numeroBonLivraison", "quantitePalette", commentaire, "fk_Client_id", "fk_Fournisseur_id", "fk_TypeZoneDepot_id", "fk_LettreVoitureEntree_id", "fk_Destinataire_id", "fk_ZoneDepot_pour_TypeZoneDepot_id") FROM stdin;
\.
COPY public.gestion_stock_bonlivraisonentree (id, "idBonLivraisonEntree", "dateReception", "numeroBonLivraison", "quantitePalette", commentaire, "fk_Client_id", "fk_Fournisseur_id", "fk_TypeZoneDepot_id", "fk_LettreVoitureEntree_id", "fk_Destinataire_id", "fk_ZoneDepot_pour_TypeZoneDepot_id") FROM '$$PATH$$/3337.dat';

--
-- Data for Name: gestion_stock_bonlivraisonsortie; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_bonlivraisonsortie (id, "idBonLivraisonSortie", "dateImpression", "numeroBonLivraison", "prixExpedition", "codeTracking", c_horodatage, "fk_BonCommandeSortie_id", "fk_LettreVoitureSortie_id") FROM stdin;
\.
COPY public.gestion_stock_bonlivraisonsortie (id, "idBonLivraisonSortie", "dateImpression", "numeroBonLivraison", "prixExpedition", "codeTracking", c_horodatage, "fk_BonCommandeSortie_id", "fk_LettreVoitureSortie_id") FROM '$$PATH$$/3339.dat';

--
-- Data for Name: gestion_stock_client; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_client (id, "idClient", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom, adresse, commentaire, telephone, email, siret, tva, source, "identifiantSource", "nomCompte", "fk_TypeArticle_id", "fk_TypeDestinataire_id", "fk_TypeFournisseur_id", "fk_TypeZone_id") FROM stdin;
\.
COPY public.gestion_stock_client (id, "idClient", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom, adresse, commentaire, telephone, email, siret, tva, source, "identifiantSource", "nomCompte", "fk_TypeArticle_id", "fk_TypeDestinataire_id", "fk_TypeFournisseur_id", "fk_TypeZone_id") FROM '$$PATH$$/3341.dat';

--
-- Data for Name: gestion_stock_colis; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_colis (id, "idColis", c_horodatage, c_nom, "c_nomCompte", "datePeremption", "emplacementConfirme", m_horodatage, m_nom, "m_nomCompte", "numeroLot", numerotation, "quantiteProduit", fk_litige_id, "fk_Article_id", "fk_UniteManutentionEntree_id", "fk_UniteManutentionSortie_id", "fk_LitigeDecision_id", "fk_ZoneDepot_id", colle) FROM stdin;
\.
COPY public.gestion_stock_colis (id, "idColis", c_horodatage, c_nom, "c_nomCompte", "datePeremption", "emplacementConfirme", m_horodatage, m_nom, "m_nomCompte", "numeroLot", numerotation, "quantiteProduit", fk_litige_id, "fk_Article_id", "fk_UniteManutentionEntree_id", "fk_UniteManutentionSortie_id", "fk_LitigeDecision_id", "fk_ZoneDepot_id", colle) FROM '$$PATH$$/3343.dat';

--
-- Data for Name: gestion_stock_contact_pour_client; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_contact_pour_client (id, "fk_Client_id", c_horodatage, c_nom, "c_nomCompte", email, "idContact", m_horodatage, m_nom, "m_nomCompte", nom, prenom, telephone, "fk_RoleContact_id") FROM stdin;
\.
COPY public.gestion_stock_contact_pour_client (id, "fk_Client_id", c_horodatage, c_nom, "c_nomCompte", email, "idContact", m_horodatage, m_nom, "m_nomCompte", nom, prenom, telephone, "fk_RoleContact_id") FROM '$$PATH$$/3345.dat';

--
-- Data for Name: gestion_stock_destinataire; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_destinataire (id, "idDestinataire", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "adresseLivraison", "adresseFacturation", departement, telephone, nom, "identifiantBonLivraison", commentaire, "codeUM", email, source, "identifiantSource", "adresseLivraison_nom", "adresseLivraison_numero", "adresseLivraison_rue", "adresseLivraison_complement_1", "adresseLivraison_complement_2", "adresseLivraison_codePostal", "adresseLivraison_localite", "delaiPeremption", "ordreTri", "fk_Pays_id", "fk_TypeDestinataire_id") FROM stdin;
\.
COPY public.gestion_stock_destinataire (id, "idDestinataire", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "adresseLivraison", "adresseFacturation", departement, telephone, nom, "identifiantBonLivraison", commentaire, "codeUM", email, source, "identifiantSource", "adresseLivraison_nom", "adresseLivraison_numero", "adresseLivraison_rue", "adresseLivraison_complement_1", "adresseLivraison_complement_2", "adresseLivraison_codePostal", "adresseLivraison_localite", "delaiPeremption", "ordreTri", "fk_Pays_id", "fk_TypeDestinataire_id") FROM '$$PATH$$/3347.dat';

--
-- Data for Name: gestion_stock_fournisseur; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_fournisseur (id, "idFournisseur", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom, source, "identifiantSource", "fk_TypeFournisseur_id") FROM stdin;
\.
COPY public.gestion_stock_fournisseur (id, "idFournisseur", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom, source, "identifiantSource", "fk_TypeFournisseur_id") FROM '$$PATH$$/3349.dat';

--
-- Data for Name: gestion_stock_lettrevoitureentree; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_lettrevoitureentree (id, "idLettreVoitureEntree", "fk_Transporteur_id", datereception, numerorecepisse, quantitecolis, quantitepalette, reclacomm, reclaquantitecolis, reclaquantitepalette) FROM stdin;
\.
COPY public.gestion_stock_lettrevoitureentree (id, "idLettreVoitureEntree", "fk_Transporteur_id", datereception, numerorecepisse, quantitecolis, quantitepalette, reclacomm, reclaquantitecolis, reclaquantitepalette) FROM '$$PATH$$/3351.dat';

--
-- Data for Name: gestion_stock_lettrevoituresortie; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_lettrevoituresortie (id, "idLettreVoitureSortie", datereception, numerorecepisse, quantitepalette, quantitecolis, reclaquantitepalette, reclaquantitecolis, reclacomm, "fk_Transporteur_id") FROM stdin;
\.
COPY public.gestion_stock_lettrevoituresortie (id, "idLettreVoitureSortie", datereception, numerorecepisse, quantitepalette, quantitecolis, reclaquantitepalette, reclaquantitecolis, reclacomm, "fk_Transporteur_id") FROM '$$PATH$$/3353.dat';

--
-- Data for Name: gestion_stock_ligneboncommandeentree_pour_boncommandeentree; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree (id, "fk_Article_id", "fk_BonCommandeEntree_id", "dateLivraison", "idLigneBonCommandeEntree", "identifiantSource", "quantiteColis", "quantiteProduit", "quantiteRecue", source) FROM stdin;
\.
COPY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree (id, "fk_Article_id", "fk_BonCommandeEntree_id", "dateLivraison", "idLigneBonCommandeEntree", "identifiantSource", "quantiteColis", "quantiteProduit", "quantiteRecue", source) FROM '$$PATH$$/3355.dat';

--
-- Data for Name: gestion_stock_ligneboncommandesortie_pour_boncommandesortie; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idLigneBonCommandeSortie", "quantiteProduitCommande", "quantiteColisCommande", "quantiteProduitALivrer", "quantiteProduitLivre", "quantiteColisLivre", "quantiteProduitPotentielle", "quantiteColisPotentielle", "differenceCommandeLivre", "differenceCommandePotentiel", termine, priorite, source, "identifiantSource", "fk_Article_id", "fk_BonCommandeSortie_id") FROM stdin;
\.
COPY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idLigneBonCommandeSortie", "quantiteProduitCommande", "quantiteColisCommande", "quantiteProduitALivrer", "quantiteProduitLivre", "quantiteColisLivre", "quantiteProduitPotentielle", "quantiteColisPotentielle", "differenceCommandeLivre", "differenceCommandePotentiel", termine, priorite, source, "identifiantSource", "fk_Article_id", "fk_BonCommandeSortie_id") FROM '$$PATH$$/3357.dat';

--
-- Data for Name: gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree (id, "idLigneBonLivraisonEntree", controle, "quantiteColis", "quantiteColisAlivrer", "quantiteColisLitige", "quantiteColisRecu", "quantiteCommande", "quantiteCommandeRecue", "quantiteDifference", "quantiteDifferenceAutre", "quantiteDifferenceRestante", "quantiteProduit", "quantiteProduitAlivrer", "quantiteProduitLitige", "quantiteProduitRecu", termine, "fk_Article_id", "fk_BonLivraisonEntree_id") FROM stdin;
\.
COPY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree (id, "idLigneBonLivraisonEntree", controle, "quantiteColis", "quantiteColisAlivrer", "quantiteColisLitige", "quantiteColisRecu", "quantiteCommande", "quantiteCommandeRecue", "quantiteDifference", "quantiteDifferenceAutre", "quantiteDifferenceRestante", "quantiteProduit", "quantiteProduitAlivrer", "quantiteProduitLitige", "quantiteProduitRecu", termine, "fk_Article_id", "fk_BonLivraisonEntree_id") FROM '$$PATH$$/3359.dat';

--
-- Data for Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie (id, "idLigneBonLivraisonSortie", "quantiteColis", "stat_quantiteColis", "fk_Article_id", "fk_BonLivraisonSortie_id", "fk_Transporteur_id") FROM stdin;
\.
COPY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie (id, "idLigneBonLivraisonSortie", "quantiteColis", "stat_quantiteColis", "fk_Article_id", "fk_BonLivraisonSortie_id", "fk_Transporteur_id") FROM '$$PATH$$/3361.dat';

--
-- Data for Name: gestion_stock_litige; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_litige (id, "idLitige", nom) FROM stdin;
\.
COPY public.gestion_stock_litige (id, "idLitige", nom) FROM '$$PATH$$/3363.dat';

--
-- Data for Name: gestion_stock_litigedecision; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_litigedecision (id, "idLitige", nom) FROM stdin;
\.
COPY public.gestion_stock_litigedecision (id, "idLitige", nom) FROM '$$PATH$$/3365.dat';

--
-- Data for Name: gestion_stock_menuimages; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_menuimages (id, title, cover1, cover2, cover3, cover4, cover5, cover6, cover7, cover8, cover9, cover10, cover11, cover12, cover13, cover14) FROM stdin;
\.
COPY public.gestion_stock_menuimages (id, title, cover1, cover2, cover3, cover4, cover5, cover6, cover7, cover8, cover9, cover10, cover11, cover12, cover13, cover14) FROM '$$PATH$$/3367.dat';

--
-- Data for Name: gestion_stock_pays_pour_destinataire; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_pays_pour_destinataire (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idPays", nom, "codeISO_2", "codeISO_3") FROM stdin;
\.
COPY public.gestion_stock_pays_pour_destinataire (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idPays", nom, "codeISO_2", "codeISO_3") FROM '$$PATH$$/3369.dat';

--
-- Data for Name: gestion_stock_rolecontact_pour_client; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_rolecontact_pour_client (id, "idRoleContact", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom) FROM stdin;
\.
COPY public.gestion_stock_rolecontact_pour_client (id, "idRoleContact", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom) FROM '$$PATH$$/3371.dat';

--
-- Data for Name: gestion_stock_transporteur; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_transporteur (id, "idTransporteur", nom, c_horodatage, c_nom, "c_nomCompte", m_horodatage, m_nom, "m_nomCompte") FROM stdin;
\.
COPY public.gestion_stock_transporteur (id, "idTransporteur", nom, c_horodatage, c_nom, "c_nomCompte", m_horodatage, m_nom, "m_nomCompte") FROM '$$PATH$$/3373.dat';

--
-- Data for Name: gestion_stock_typearticle_pour_article; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_typearticle_pour_article (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idTypeArticle", nom) FROM stdin;
\.
COPY public.gestion_stock_typearticle_pour_article (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idTypeArticle", nom) FROM '$$PATH$$/3375.dat';

--
-- Data for Name: gestion_stock_typeboncommandesortie_pour_boncommandesortie; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_typeboncommandesortie_pour_boncommandesortie (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idTypeBonCommandeSortie", nom) FROM stdin;
\.
COPY public.gestion_stock_typeboncommandesortie_pour_boncommandesortie (id, c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, "idTypeBonCommandeSortie", nom) FROM '$$PATH$$/3377.dat';

--
-- Data for Name: gestion_stock_typedestinataire_pour_destinataire; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_typedestinataire_pour_destinataire (id, "idTypeDestinataire", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom) FROM stdin;
\.
COPY public.gestion_stock_typedestinataire_pour_destinataire (id, "idTypeDestinataire", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom) FROM '$$PATH$$/3379.dat';

--
-- Data for Name: gestion_stock_typefournisseur_pour_fournisseur; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_typefournisseur_pour_fournisseur (id, "idTypeFournisseur", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom) FROM stdin;
\.
COPY public.gestion_stock_typefournisseur_pour_fournisseur (id, "idTypeFournisseur", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom) FROM '$$PATH$$/3381.dat';

--
-- Data for Name: gestion_stock_typezonedepot; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_typezonedepot (id, "idTypeZoneDepot", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom) FROM stdin;
\.
COPY public.gestion_stock_typezonedepot (id, "idTypeZoneDepot", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom) FROM '$$PATH$$/3383.dat';

--
-- Data for Name: gestion_stock_unitemanutentionentree; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_unitemanutentionentree (id, "idUniteManutentionEntree", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, numero, "dateReception", stock, "fk_BonLivraisonEntree_id") FROM stdin;
\.
COPY public.gestion_stock_unitemanutentionentree (id, "idUniteManutentionEntree", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, numero, "dateReception", stock, "fk_BonLivraisonEntree_id") FROM '$$PATH$$/3385.dat';

--
-- Data for Name: gestion_stock_unitemanutentionsortie; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_unitemanutentionsortie (id, "idUniteManutentionSortie", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, numero, "dateReception", "fk_BonCommandeSortie_id", "fk_BonLivraisonSortie_id", "poidsBrut", "poidsDifference", "poidsNet", "poidsTare", "dateExpedition", "dateOuverture") FROM stdin;
\.
COPY public.gestion_stock_unitemanutentionsortie (id, "idUniteManutentionSortie", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, numero, "dateReception", "fk_BonCommandeSortie_id", "fk_BonLivraisonSortie_id", "poidsBrut", "poidsDifference", "poidsNet", "poidsTare", "dateExpedition", "dateOuverture") FROM '$$PATH$$/3387.dat';

--
-- Data for Name: gestion_stock_zonedepot_pour_typezonedepot; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.gestion_stock_zonedepot_pour_typezonedepot (id, "idZoneDepot", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom, "fk_TypeZoneDepot_id") FROM stdin;
\.
COPY public.gestion_stock_zonedepot_pour_typezonedepot (id, "idZoneDepot", c_nom, "c_nomCompte", c_horodatage, m_nom, "m_nomCompte", m_horodatage, nom, "fk_TypeZoneDepot_id") FROM '$$PATH$$/3389.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 148, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 10, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 37, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 74, true);


--
-- Name: gestion_stock_article_historique_pour_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_article_historique_pour_article_id_seq', 1, false);


--
-- Name: gestion_stock_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_article_id_seq', 5, true);


--
-- Name: gestion_stock_boncommandeentree_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_boncommandeentree_id_seq', 1, false);


--
-- Name: gestion_stock_boncommandesortie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_boncommandesortie_id_seq', 6, true);


--
-- Name: gestion_stock_bonlivraisonentree_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_bonlivraisonentree_id_seq', 3, true);


--
-- Name: gestion_stock_bonlivraisonsortie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_bonlivraisonsortie_id_seq', 1, false);


--
-- Name: gestion_stock_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_client_id_seq', 1, true);


--
-- Name: gestion_stock_colis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_colis_id_seq', 164, true);


--
-- Name: gestion_stock_contact_pour_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_contact_pour_client_id_seq', 2, true);


--
-- Name: gestion_stock_destinataire_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_destinataire_id_seq', 2, true);


--
-- Name: gestion_stock_fournisseur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_fournisseur_id_seq', 8, true);


--
-- Name: gestion_stock_lettrevoitureentree_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_lettrevoitureentree_id_seq', 1, true);


--
-- Name: gestion_stock_lettrevoituresortie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_lettrevoituresortie_id_seq', 1, false);


--
-- Name: gestion_stock_ligneboncommandeentree_pour_boncommandeent_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_ligneboncommandeentree_pour_boncommandeent_id_seq', 1, false);


--
-- Name: gestion_stock_ligneboncommandesortie_pour_import_boncomm_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_ligneboncommandesortie_pour_import_boncomm_id_seq', 21, true);


--
-- Name: gestion_stock_lignebonlivraisonentree_pour_bonlivraisone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisone_id_seq', 7, true);


--
-- Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisons_id_seq', 1, false);


--
-- Name: gestion_stock_litige_pour_colis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_litige_pour_colis_id_seq', 1, true);


--
-- Name: gestion_stock_litigedecision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_litigedecision_id_seq', 6, true);


--
-- Name: gestion_stock_menuimages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_menuimages_id_seq', 1, false);


--
-- Name: gestion_stock_pays_pour_destinataire_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_pays_pour_destinataire_id_seq', 1, true);


--
-- Name: gestion_stock_rolecontact_pour_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_rolecontact_pour_client_id_seq', 3, true);


--
-- Name: gestion_stock_transporteur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_transporteur_id_seq', 11, true);


--
-- Name: gestion_stock_typearticle_pour_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_typearticle_pour_article_id_seq', 1, true);


--
-- Name: gestion_stock_typeboncommandesortie_pour_boncommandesort_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_typeboncommandesortie_pour_boncommandesort_id_seq', 1, false);


--
-- Name: gestion_stock_typedestinataire_pour_destinataire_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_typedestinataire_pour_destinataire_id_seq', 1, true);


--
-- Name: gestion_stock_typefournisseur_pour_fournisseur_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_typefournisseur_pour_fournisseur_id_seq', 1, true);


--
-- Name: gestion_stock_typezonedepot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_typezonedepot_id_seq', 1, true);


--
-- Name: gestion_stock_unitemanutentionentree_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_unitemanutentionentree_id_seq', 8, true);


--
-- Name: gestion_stock_unitemanutentionsortie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_unitemanutentionsortie_id_seq', 8, true);


--
-- Name: gestion_stock_zonedepot_pour_typezonedepot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.gestion_stock_zonedepot_pour_typezonedepot_id_seq', 3, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: gestion_stock_article_historique_pour_article gestion_stock_article_historique_pour_article_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_article_historique_pour_article
    ADD CONSTRAINT gestion_stock_article_historique_pour_article_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_article gestion_stock_article_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_article
    ADD CONSTRAINT gestion_stock_article_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_boncommandeentree gestion_stock_boncommandeentree_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_boncommandeentree
    ADD CONSTRAINT gestion_stock_boncommandeentree_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_boncommandesortie gestion_stock_boncommandesortie_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_boncommandesortie
    ADD CONSTRAINT gestion_stock_boncommandesortie_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_bonlivraisonentree gestion_stock_bonlivraisonentree_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree
    ADD CONSTRAINT gestion_stock_bonlivraisonentree_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_bonlivraisonsortie gestion_stock_bonlivraisonsortie_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonsortie
    ADD CONSTRAINT gestion_stock_bonlivraisonsortie_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_client gestion_stock_client_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_client
    ADD CONSTRAINT gestion_stock_client_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_colis gestion_stock_colis_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_colis
    ADD CONSTRAINT gestion_stock_colis_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_contact_pour_client gestion_stock_contact_pour_client_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_contact_pour_client
    ADD CONSTRAINT gestion_stock_contact_pour_client_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_destinataire gestion_stock_destinataire_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_destinataire
    ADD CONSTRAINT gestion_stock_destinataire_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_fournisseur gestion_stock_fournisseur_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_fournisseur
    ADD CONSTRAINT gestion_stock_fournisseur_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_lettrevoitureentree gestion_stock_lettrevoitureentree_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lettrevoitureentree
    ADD CONSTRAINT gestion_stock_lettrevoitureentree_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_lettrevoituresortie gestion_stock_lettrevoituresortie_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lettrevoituresortie
    ADD CONSTRAINT gestion_stock_lettrevoituresortie_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_ligneboncommandeentree_pour_boncommandeentree gestion_stock_ligneboncommandeentree_pour_boncommandeentre_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree
    ADD CONSTRAINT gestion_stock_ligneboncommandeentree_pour_boncommandeentre_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_ligneboncommandesortie_pour_boncommandesortie gestion_stock_ligneboncommandesortie_pour_import_boncomman_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie
    ADD CONSTRAINT gestion_stock_ligneboncommandesortie_pour_import_boncomman_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree gestion_stock_lignebonlivraisonentree_pour_bonlivraisonent_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree
    ADD CONSTRAINT gestion_stock_lignebonlivraisonentree_pour_bonlivraisonent_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsor_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie
    ADD CONSTRAINT gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsor_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_litige gestion_stock_litige_pour_colis_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_litige
    ADD CONSTRAINT gestion_stock_litige_pour_colis_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_litigedecision gestion_stock_litigedecision_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_litigedecision
    ADD CONSTRAINT gestion_stock_litigedecision_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_menuimages gestion_stock_menuimages_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_menuimages
    ADD CONSTRAINT gestion_stock_menuimages_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_pays_pour_destinataire gestion_stock_pays_pour_destinataire_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_pays_pour_destinataire
    ADD CONSTRAINT gestion_stock_pays_pour_destinataire_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_rolecontact_pour_client gestion_stock_rolecontact_pour_client_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_rolecontact_pour_client
    ADD CONSTRAINT gestion_stock_rolecontact_pour_client_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_transporteur gestion_stock_transporteur_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_transporteur
    ADD CONSTRAINT gestion_stock_transporteur_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_typearticle_pour_article gestion_stock_typearticle_pour_article_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typearticle_pour_article
    ADD CONSTRAINT gestion_stock_typearticle_pour_article_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_typeboncommandesortie_pour_boncommandesortie gestion_stock_typeboncommandesortie_pour_boncommandesortie_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typeboncommandesortie_pour_boncommandesortie
    ADD CONSTRAINT gestion_stock_typeboncommandesortie_pour_boncommandesortie_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_typedestinataire_pour_destinataire gestion_stock_typedestinataire_pour_destinataire_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typedestinataire_pour_destinataire
    ADD CONSTRAINT gestion_stock_typedestinataire_pour_destinataire_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_typefournisseur_pour_fournisseur gestion_stock_typefournisseur_pour_fournisseur_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typefournisseur_pour_fournisseur
    ADD CONSTRAINT gestion_stock_typefournisseur_pour_fournisseur_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_typezonedepot gestion_stock_typezonedepot_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_typezonedepot
    ADD CONSTRAINT gestion_stock_typezonedepot_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_unitemanutentionentree gestion_stock_unitemanutentionentree_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_unitemanutentionentree
    ADD CONSTRAINT gestion_stock_unitemanutentionentree_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_unitemanutentionsortie gestion_stock_unitemanutentionsortie_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_unitemanutentionsortie
    ADD CONSTRAINT gestion_stock_unitemanutentionsortie_pkey PRIMARY KEY (id);


--
-- Name: gestion_stock_zonedepot_pour_typezonedepot gestion_stock_zonedepot_pour_typezonedepot_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_zonedepot_pour_typezonedepot
    ADD CONSTRAINT gestion_stock_zonedepot_pour_typezonedepot_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: gestion_stock_article_fk_Fournisseur_id_af746084; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_article_fk_Fournisseur_id_af746084" ON public.gestion_stock_article USING btree ("fk_Fournisseur_id");


--
-- Name: gestion_stock_article_fk_TypeArticle_id_df0d768b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_article_fk_TypeArticle_id_df0d768b" ON public.gestion_stock_article USING btree ("fk_TypeArticle_id");


--
-- Name: gestion_stock_article_hist_fk_Article_id_cc2ae50c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_article_hist_fk_Article_id_cc2ae50c" ON public.gestion_stock_article_historique_pour_article USING btree ("fk_Article_id");


--
-- Name: gestion_stock_article_hist_fk_Fournisseur_id_26a4d479; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_article_hist_fk_Fournisseur_id_26a4d479" ON public.gestion_stock_article_historique_pour_article USING btree ("fk_Fournisseur_id");


--
-- Name: gestion_stock_boncommandesortie_fk_Client_id_d89f031e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_boncommandesortie_fk_Client_id_d89f031e" ON public.gestion_stock_boncommandesortie USING btree ("fk_Client_id");


--
-- Name: gestion_stock_boncommandesortie_fk_Destinataire_id_3ca2e851; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_boncommandesortie_fk_Destinataire_id_3ca2e851" ON public.gestion_stock_boncommandesortie USING btree ("fk_Destinataire_id");


--
-- Name: gestion_stock_boncommandesortie_fk_Transporteur_id_6d260680; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_boncommandesortie_fk_Transporteur_id_6d260680" ON public.gestion_stock_boncommandesortie USING btree ("fk_Transporteur_id");


--
-- Name: gestion_stock_bonlivraison_fk_BonCommandeSortie_id_312cf0b1; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_bonlivraison_fk_BonCommandeSortie_id_312cf0b1" ON public.gestion_stock_bonlivraisonsortie USING btree ("fk_BonCommandeSortie_id");


--
-- Name: gestion_stock_bonlivraison_fk_LettreVoitureEntree_id_bd1beab9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_bonlivraison_fk_LettreVoitureEntree_id_bd1beab9" ON public.gestion_stock_bonlivraisonentree USING btree ("fk_LettreVoitureEntree_id");


--
-- Name: gestion_stock_bonlivraison_fk_LettreVoitureSortie_id_d498587e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_bonlivraison_fk_LettreVoitureSortie_id_d498587e" ON public.gestion_stock_bonlivraisonsortie USING btree ("fk_LettreVoitureSortie_id");


--
-- Name: gestion_stock_bonlivraison_fk_ZoneDepot_pour_TypeZone_ad6ef601; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_bonlivraison_fk_ZoneDepot_pour_TypeZone_ad6ef601" ON public.gestion_stock_bonlivraisonentree USING btree ("fk_ZoneDepot_pour_TypeZoneDepot_id");


--
-- Name: gestion_stock_bonlivraisonentree_fk_Client_id_17e7f6cb; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_bonlivraisonentree_fk_Client_id_17e7f6cb" ON public.gestion_stock_bonlivraisonentree USING btree ("fk_Client_id");


--
-- Name: gestion_stock_bonlivraisonentree_fk_Destinataire_id_0b3e4c09; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_bonlivraisonentree_fk_Destinataire_id_0b3e4c09" ON public.gestion_stock_bonlivraisonentree USING btree ("fk_Destinataire_id");


--
-- Name: gestion_stock_bonlivraisonentree_fk_Fournisseur_id_a14cc499; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_bonlivraisonentree_fk_Fournisseur_id_a14cc499" ON public.gestion_stock_bonlivraisonentree USING btree ("fk_Fournisseur_id");


--
-- Name: gestion_stock_bonlivraisonentree_fk_TypeZoneDepot_id_e0d5dce3; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_bonlivraisonentree_fk_TypeZoneDepot_id_e0d5dce3" ON public.gestion_stock_bonlivraisonentree USING btree ("fk_TypeZoneDepot_id");


--
-- Name: gestion_stock_client_fk_TypeArticle_id_1af52016; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_client_fk_TypeArticle_id_1af52016" ON public.gestion_stock_client USING btree ("fk_TypeArticle_id");


--
-- Name: gestion_stock_client_fk_TypeDestinataire_id_d5074d84; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_client_fk_TypeDestinataire_id_d5074d84" ON public.gestion_stock_client USING btree ("fk_TypeDestinataire_id");


--
-- Name: gestion_stock_client_fk_TypeFournisseur_id_0cbea6bf; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_client_fk_TypeFournisseur_id_0cbea6bf" ON public.gestion_stock_client USING btree ("fk_TypeFournisseur_id");


--
-- Name: gestion_stock_client_fk_TypeZone_id_a48ba631; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_client_fk_TypeZone_id_a48ba631" ON public.gestion_stock_client USING btree ("fk_TypeZone_id");


--
-- Name: gestion_stock_colis_fk_Article_id_4aa25755; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_colis_fk_Article_id_4aa25755" ON public.gestion_stock_colis USING btree ("fk_Article_id");


--
-- Name: gestion_stock_colis_fk_LitigeDecision_id_75ff08bd; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_colis_fk_LitigeDecision_id_75ff08bd" ON public.gestion_stock_colis USING btree ("fk_LitigeDecision_id");


--
-- Name: gestion_stock_colis_fk_UniteManutentionEntree_id_16c75c12; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_colis_fk_UniteManutentionEntree_id_16c75c12" ON public.gestion_stock_colis USING btree ("fk_UniteManutentionEntree_id");


--
-- Name: gestion_stock_colis_fk_UniteManutentionSortie_id_4a8b42f0; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_colis_fk_UniteManutentionSortie_id_4a8b42f0" ON public.gestion_stock_colis USING btree ("fk_UniteManutentionSortie_id");


--
-- Name: gestion_stock_colis_fk_ZoneDepot_id_8b581af3; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_colis_fk_ZoneDepot_id_8b581af3" ON public.gestion_stock_colis USING btree ("fk_ZoneDepot_id");


--
-- Name: gestion_stock_colis_fk_litige_id_87e26c63; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX gestion_stock_colis_fk_litige_id_87e26c63 ON public.gestion_stock_colis USING btree (fk_litige_id);


--
-- Name: gestion_stock_contact_pour_client_fk_Client_id_29a22d77; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_contact_pour_client_fk_Client_id_29a22d77" ON public.gestion_stock_contact_pour_client USING btree ("fk_Client_id");


--
-- Name: gestion_stock_contact_pour_client_fk_RoleContact_id_17dd98ed; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_contact_pour_client_fk_RoleContact_id_17dd98ed" ON public.gestion_stock_contact_pour_client USING btree ("fk_RoleContact_id");


--
-- Name: gestion_stock_destinataire_fk_Pays_id_f2f9f054; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_destinataire_fk_Pays_id_f2f9f054" ON public.gestion_stock_destinataire USING btree ("fk_Pays_id");


--
-- Name: gestion_stock_destinataire_fk_TypeDestinataire_id_473bb345; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_destinataire_fk_TypeDestinataire_id_473bb345" ON public.gestion_stock_destinataire USING btree ("fk_TypeDestinataire_id");


--
-- Name: gestion_stock_fournisseur_fk_TypeFournisseur_id_9a2685c4; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_fournisseur_fk_TypeFournisseur_id_9a2685c4" ON public.gestion_stock_fournisseur USING btree ("fk_TypeFournisseur_id");


--
-- Name: gestion_stock_lettrevoitureentree_fk_Transporteur_id_b4dbf6db; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_lettrevoitureentree_fk_Transporteur_id_b4dbf6db" ON public.gestion_stock_lettrevoitureentree USING btree ("fk_Transporteur_id");


--
-- Name: gestion_stock_lettrevoituresortie_fk_Transporteur_id_81d31722; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_lettrevoituresortie_fk_Transporteur_id_81d31722" ON public.gestion_stock_lettrevoituresortie USING btree ("fk_Transporteur_id");


--
-- Name: gestion_stock_ligneboncomm_fk_Article_id_35f597d6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_ligneboncomm_fk_Article_id_35f597d6" ON public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree USING btree ("fk_Article_id");


--
-- Name: gestion_stock_ligneboncomm_fk_Article_id_9eee0e5e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_ligneboncomm_fk_Article_id_9eee0e5e" ON public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie USING btree ("fk_Article_id");


--
-- Name: gestion_stock_ligneboncomm_fk_BonCommandeEntree_id_32310d1e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_ligneboncomm_fk_BonCommandeEntree_id_32310d1e" ON public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree USING btree ("fk_BonCommandeEntree_id");


--
-- Name: gestion_stock_ligneboncomm_fk_BonCommandeSortie_id_e1eaff1a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_ligneboncomm_fk_BonCommandeSortie_id_e1eaff1a" ON public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie USING btree ("fk_BonCommandeSortie_id");


--
-- Name: gestion_stock_lignebonlivr_fk_Article_id_2079106f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_lignebonlivr_fk_Article_id_2079106f" ON public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie USING btree ("fk_Article_id");


--
-- Name: gestion_stock_lignebonlivr_fk_Article_id_48a1d197; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_lignebonlivr_fk_Article_id_48a1d197" ON public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree USING btree ("fk_Article_id");


--
-- Name: gestion_stock_lignebonlivr_fk_BonLivraisonEntree_id_3f146f68; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_lignebonlivr_fk_BonLivraisonEntree_id_3f146f68" ON public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree USING btree ("fk_BonLivraisonEntree_id");


--
-- Name: gestion_stock_lignebonlivr_fk_BonLivraisonSortie_id_98e360b6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_lignebonlivr_fk_BonLivraisonSortie_id_98e360b6" ON public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie USING btree ("fk_BonLivraisonSortie_id");


--
-- Name: gestion_stock_lignebonlivr_fk_Transporteur_id_e0b4694c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_lignebonlivr_fk_Transporteur_id_e0b4694c" ON public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie USING btree ("fk_Transporteur_id");


--
-- Name: gestion_stock_unitemanuten_fk_BonCommandeSortie_id_678ef194; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_unitemanuten_fk_BonCommandeSortie_id_678ef194" ON public.gestion_stock_unitemanutentionsortie USING btree ("fk_BonCommandeSortie_id");


--
-- Name: gestion_stock_unitemanuten_fk_BonLivraisonEntree_id_077f0e37; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_unitemanuten_fk_BonLivraisonEntree_id_077f0e37" ON public.gestion_stock_unitemanutentionentree USING btree ("fk_BonLivraisonEntree_id");


--
-- Name: gestion_stock_unitemanuten_fk_BonLivraisonSortie_id_e418aaf9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_unitemanuten_fk_BonLivraisonSortie_id_e418aaf9" ON public.gestion_stock_unitemanutentionsortie USING btree ("fk_BonLivraisonSortie_id");


--
-- Name: gestion_stock_zonedepot_po_fk_TypeZoneDepot_id_2d3337f8; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "gestion_stock_zonedepot_po_fk_TypeZoneDepot_id_2d3337f8" ON public.gestion_stock_zonedepot_pour_typezonedepot USING btree ("fk_TypeZoneDepot_id");


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_article_historique_pour_article gestion_stock_articl_fk_Article_id_cc2ae50c_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_article_historique_pour_article
    ADD CONSTRAINT "gestion_stock_articl_fk_Article_id_cc2ae50c_fk_gestion_s" FOREIGN KEY ("fk_Article_id") REFERENCES public.gestion_stock_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_article_historique_pour_article gestion_stock_articl_fk_Fournisseur_id_26a4d479_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_article_historique_pour_article
    ADD CONSTRAINT "gestion_stock_articl_fk_Fournisseur_id_26a4d479_fk_gestion_s" FOREIGN KEY ("fk_Fournisseur_id") REFERENCES public.gestion_stock_fournisseur(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_article gestion_stock_articl_fk_Fournisseur_id_af746084_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_article
    ADD CONSTRAINT "gestion_stock_articl_fk_Fournisseur_id_af746084_fk_gestion_s" FOREIGN KEY ("fk_Fournisseur_id") REFERENCES public.gestion_stock_fournisseur(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_article gestion_stock_articl_fk_TypeArticle_id_df0d768b_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_article
    ADD CONSTRAINT "gestion_stock_articl_fk_TypeArticle_id_df0d768b_fk_gestion_s" FOREIGN KEY ("fk_TypeArticle_id") REFERENCES public.gestion_stock_typearticle_pour_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_boncommandesortie gestion_stock_boncom_fk_Client_id_d89f031e_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_boncommandesortie
    ADD CONSTRAINT "gestion_stock_boncom_fk_Client_id_d89f031e_fk_gestion_s" FOREIGN KEY ("fk_Client_id") REFERENCES public.gestion_stock_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_boncommandesortie gestion_stock_boncom_fk_Destinataire_id_3ca2e851_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_boncommandesortie
    ADD CONSTRAINT "gestion_stock_boncom_fk_Destinataire_id_3ca2e851_fk_gestion_s" FOREIGN KEY ("fk_Destinataire_id") REFERENCES public.gestion_stock_destinataire(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_boncommandesortie gestion_stock_boncom_fk_Transporteur_id_6d260680_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_boncommandesortie
    ADD CONSTRAINT "gestion_stock_boncom_fk_Transporteur_id_6d260680_fk_gestion_s" FOREIGN KEY ("fk_Transporteur_id") REFERENCES public.gestion_stock_transporteur(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_bonlivraisonsortie gestion_stock_bonliv_fk_BonCommandeSortie_312cf0b1_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonsortie
    ADD CONSTRAINT "gestion_stock_bonliv_fk_BonCommandeSortie_312cf0b1_fk_gestion_s" FOREIGN KEY ("fk_BonCommandeSortie_id") REFERENCES public.gestion_stock_boncommandesortie(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_bonlivraisonentree gestion_stock_bonliv_fk_Client_id_17e7f6cb_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree
    ADD CONSTRAINT "gestion_stock_bonliv_fk_Client_id_17e7f6cb_fk_gestion_s" FOREIGN KEY ("fk_Client_id") REFERENCES public.gestion_stock_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_bonlivraisonentree gestion_stock_bonliv_fk_Destinataire_id_0b3e4c09_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree
    ADD CONSTRAINT "gestion_stock_bonliv_fk_Destinataire_id_0b3e4c09_fk_gestion_s" FOREIGN KEY ("fk_Destinataire_id") REFERENCES public.gestion_stock_destinataire(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_bonlivraisonentree gestion_stock_bonliv_fk_Fournisseur_id_a14cc499_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree
    ADD CONSTRAINT "gestion_stock_bonliv_fk_Fournisseur_id_a14cc499_fk_gestion_s" FOREIGN KEY ("fk_Fournisseur_id") REFERENCES public.gestion_stock_fournisseur(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_bonlivraisonentree gestion_stock_bonliv_fk_LettreVoitureEntr_bd1beab9_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree
    ADD CONSTRAINT "gestion_stock_bonliv_fk_LettreVoitureEntr_bd1beab9_fk_gestion_s" FOREIGN KEY ("fk_LettreVoitureEntree_id") REFERENCES public.gestion_stock_lettrevoitureentree(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_bonlivraisonsortie gestion_stock_bonliv_fk_LettreVoitureSort_d498587e_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonsortie
    ADD CONSTRAINT "gestion_stock_bonliv_fk_LettreVoitureSort_d498587e_fk_gestion_s" FOREIGN KEY ("fk_LettreVoitureSortie_id") REFERENCES public.gestion_stock_lettrevoituresortie(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_bonlivraisonentree gestion_stock_bonliv_fk_TypeZoneDepot_id_e0d5dce3_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree
    ADD CONSTRAINT "gestion_stock_bonliv_fk_TypeZoneDepot_id_e0d5dce3_fk_gestion_s" FOREIGN KEY ("fk_TypeZoneDepot_id") REFERENCES public.gestion_stock_typezonedepot(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_bonlivraisonentree gestion_stock_bonliv_fk_ZoneDepot_pour_Ty_ad6ef601_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_bonlivraisonentree
    ADD CONSTRAINT "gestion_stock_bonliv_fk_ZoneDepot_pour_Ty_ad6ef601_fk_gestion_s" FOREIGN KEY ("fk_ZoneDepot_pour_TypeZoneDepot_id") REFERENCES public.gestion_stock_zonedepot_pour_typezonedepot(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_client gestion_stock_client_fk_TypeArticle_id_1af52016_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_client
    ADD CONSTRAINT "gestion_stock_client_fk_TypeArticle_id_1af52016_fk_gestion_s" FOREIGN KEY ("fk_TypeArticle_id") REFERENCES public.gestion_stock_typearticle_pour_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_client gestion_stock_client_fk_TypeDestinataire__d5074d84_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_client
    ADD CONSTRAINT "gestion_stock_client_fk_TypeDestinataire__d5074d84_fk_gestion_s" FOREIGN KEY ("fk_TypeDestinataire_id") REFERENCES public.gestion_stock_typedestinataire_pour_destinataire(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_client gestion_stock_client_fk_TypeFournisseur_i_0cbea6bf_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_client
    ADD CONSTRAINT "gestion_stock_client_fk_TypeFournisseur_i_0cbea6bf_fk_gestion_s" FOREIGN KEY ("fk_TypeFournisseur_id") REFERENCES public.gestion_stock_typefournisseur_pour_fournisseur(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_client gestion_stock_client_fk_TypeZone_id_a48ba631_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_client
    ADD CONSTRAINT "gestion_stock_client_fk_TypeZone_id_a48ba631_fk_gestion_s" FOREIGN KEY ("fk_TypeZone_id") REFERENCES public.gestion_stock_typezonedepot(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_colis gestion_stock_colis_fk_Article_id_4aa25755_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_colis
    ADD CONSTRAINT "gestion_stock_colis_fk_Article_id_4aa25755_fk_gestion_s" FOREIGN KEY ("fk_Article_id") REFERENCES public.gestion_stock_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_colis gestion_stock_colis_fk_LitigeDecision_id_75ff08bd_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_colis
    ADD CONSTRAINT "gestion_stock_colis_fk_LitigeDecision_id_75ff08bd_fk_gestion_s" FOREIGN KEY ("fk_LitigeDecision_id") REFERENCES public.gestion_stock_litigedecision(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_colis gestion_stock_colis_fk_UniteManutentionE_16c75c12_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_colis
    ADD CONSTRAINT "gestion_stock_colis_fk_UniteManutentionE_16c75c12_fk_gestion_s" FOREIGN KEY ("fk_UniteManutentionEntree_id") REFERENCES public.gestion_stock_unitemanutentionentree(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_colis gestion_stock_colis_fk_UniteManutentionS_4a8b42f0_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_colis
    ADD CONSTRAINT "gestion_stock_colis_fk_UniteManutentionS_4a8b42f0_fk_gestion_s" FOREIGN KEY ("fk_UniteManutentionSortie_id") REFERENCES public.gestion_stock_unitemanutentionsortie(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_colis gestion_stock_colis_fk_ZoneDepot_id_8b581af3_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_colis
    ADD CONSTRAINT "gestion_stock_colis_fk_ZoneDepot_id_8b581af3_fk_gestion_s" FOREIGN KEY ("fk_ZoneDepot_id") REFERENCES public.gestion_stock_zonedepot_pour_typezonedepot(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_colis gestion_stock_colis_fk_litige_id_87e26c63_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_colis
    ADD CONSTRAINT gestion_stock_colis_fk_litige_id_87e26c63_fk_gestion_s FOREIGN KEY (fk_litige_id) REFERENCES public.gestion_stock_litige(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_contact_pour_client gestion_stock_contac_fk_Client_id_29a22d77_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_contact_pour_client
    ADD CONSTRAINT "gestion_stock_contac_fk_Client_id_29a22d77_fk_gestion_s" FOREIGN KEY ("fk_Client_id") REFERENCES public.gestion_stock_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_contact_pour_client gestion_stock_contac_fk_RoleContact_id_17dd98ed_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_contact_pour_client
    ADD CONSTRAINT "gestion_stock_contac_fk_RoleContact_id_17dd98ed_fk_gestion_s" FOREIGN KEY ("fk_RoleContact_id") REFERENCES public.gestion_stock_rolecontact_pour_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_destinataire gestion_stock_destin_fk_Pays_id_f2f9f054_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_destinataire
    ADD CONSTRAINT "gestion_stock_destin_fk_Pays_id_f2f9f054_fk_gestion_s" FOREIGN KEY ("fk_Pays_id") REFERENCES public.gestion_stock_pays_pour_destinataire(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_destinataire gestion_stock_destin_fk_TypeDestinataire__473bb345_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_destinataire
    ADD CONSTRAINT "gestion_stock_destin_fk_TypeDestinataire__473bb345_fk_gestion_s" FOREIGN KEY ("fk_TypeDestinataire_id") REFERENCES public.gestion_stock_typedestinataire_pour_destinataire(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_fournisseur gestion_stock_fourni_fk_TypeFournisseur_i_9a2685c4_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_fournisseur
    ADD CONSTRAINT "gestion_stock_fourni_fk_TypeFournisseur_i_9a2685c4_fk_gestion_s" FOREIGN KEY ("fk_TypeFournisseur_id") REFERENCES public.gestion_stock_typefournisseur_pour_fournisseur(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_lettrevoituresortie gestion_stock_lettre_fk_Transporteur_id_81d31722_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lettrevoituresortie
    ADD CONSTRAINT "gestion_stock_lettre_fk_Transporteur_id_81d31722_fk_gestion_s" FOREIGN KEY ("fk_Transporteur_id") REFERENCES public.gestion_stock_transporteur(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_lettrevoitureentree gestion_stock_lettre_fk_Transporteur_id_b4dbf6db_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lettrevoitureentree
    ADD CONSTRAINT "gestion_stock_lettre_fk_Transporteur_id_b4dbf6db_fk_gestion_s" FOREIGN KEY ("fk_Transporteur_id") REFERENCES public.gestion_stock_transporteur(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie gestion_stock_ligneb_fk_Article_id_2079106f_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie
    ADD CONSTRAINT "gestion_stock_ligneb_fk_Article_id_2079106f_fk_gestion_s" FOREIGN KEY ("fk_Article_id") REFERENCES public.gestion_stock_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_ligneboncommandeentree_pour_boncommandeentree gestion_stock_ligneb_fk_Article_id_35f597d6_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree
    ADD CONSTRAINT "gestion_stock_ligneb_fk_Article_id_35f597d6_fk_gestion_s" FOREIGN KEY ("fk_Article_id") REFERENCES public.gestion_stock_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree gestion_stock_ligneb_fk_Article_id_48a1d197_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree
    ADD CONSTRAINT "gestion_stock_ligneb_fk_Article_id_48a1d197_fk_gestion_s" FOREIGN KEY ("fk_Article_id") REFERENCES public.gestion_stock_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_ligneboncommandesortie_pour_boncommandesortie gestion_stock_ligneb_fk_Article_id_9eee0e5e_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie
    ADD CONSTRAINT "gestion_stock_ligneb_fk_Article_id_9eee0e5e_fk_gestion_s" FOREIGN KEY ("fk_Article_id") REFERENCES public.gestion_stock_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_ligneboncommandeentree_pour_boncommandeentree gestion_stock_ligneb_fk_BonCommandeEntree_32310d1e_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_ligneboncommandeentree_pour_boncommandeentree
    ADD CONSTRAINT "gestion_stock_ligneb_fk_BonCommandeEntree_32310d1e_fk_gestion_s" FOREIGN KEY ("fk_BonCommandeEntree_id") REFERENCES public.gestion_stock_boncommandeentree(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_ligneboncommandesortie_pour_boncommandesortie gestion_stock_ligneb_fk_BonCommandeSortie_e1eaff1a_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_ligneboncommandesortie_pour_boncommandesortie
    ADD CONSTRAINT "gestion_stock_ligneb_fk_BonCommandeSortie_e1eaff1a_fk_gestion_s" FOREIGN KEY ("fk_BonCommandeSortie_id") REFERENCES public.gestion_stock_boncommandesortie(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree gestion_stock_ligneb_fk_BonLivraisonEntre_3f146f68_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonentree_pour_bonlivraisonentree
    ADD CONSTRAINT "gestion_stock_ligneb_fk_BonLivraisonEntre_3f146f68_fk_gestion_s" FOREIGN KEY ("fk_BonLivraisonEntree_id") REFERENCES public.gestion_stock_bonlivraisonentree(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie gestion_stock_ligneb_fk_BonLivraisonSorti_98e360b6_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie
    ADD CONSTRAINT "gestion_stock_ligneb_fk_BonLivraisonSorti_98e360b6_fk_gestion_s" FOREIGN KEY ("fk_BonLivraisonSortie_id") REFERENCES public.gestion_stock_bonlivraisonsortie(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie gestion_stock_ligneb_fk_Transporteur_id_e0b4694c_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_lignebonlivraisonsortie_pour_bonlivraisonsortie
    ADD CONSTRAINT "gestion_stock_ligneb_fk_Transporteur_id_e0b4694c_fk_gestion_s" FOREIGN KEY ("fk_Transporteur_id") REFERENCES public.gestion_stock_transporteur(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_unitemanutentionsortie gestion_stock_unitem_fk_BonCommandeSortie_678ef194_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_unitemanutentionsortie
    ADD CONSTRAINT "gestion_stock_unitem_fk_BonCommandeSortie_678ef194_fk_gestion_s" FOREIGN KEY ("fk_BonCommandeSortie_id") REFERENCES public.gestion_stock_boncommandesortie(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_unitemanutentionentree gestion_stock_unitem_fk_BonLivraisonEntre_077f0e37_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_unitemanutentionentree
    ADD CONSTRAINT "gestion_stock_unitem_fk_BonLivraisonEntre_077f0e37_fk_gestion_s" FOREIGN KEY ("fk_BonLivraisonEntree_id") REFERENCES public.gestion_stock_bonlivraisonentree(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_unitemanutentionsortie gestion_stock_unitem_fk_BonLivraisonSorti_e418aaf9_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_unitemanutentionsortie
    ADD CONSTRAINT "gestion_stock_unitem_fk_BonLivraisonSorti_e418aaf9_fk_gestion_s" FOREIGN KEY ("fk_BonLivraisonSortie_id") REFERENCES public.gestion_stock_bonlivraisonsortie(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gestion_stock_zonedepot_pour_typezonedepot gestion_stock_zonede_fk_TypeZoneDepot_id_2d3337f8_fk_gestion_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.gestion_stock_zonedepot_pour_typezonedepot
    ADD CONSTRAINT "gestion_stock_zonede_fk_TypeZoneDepot_id_2d3337f8_fk_gestion_s" FOREIGN KEY ("fk_TypeZoneDepot_id") REFERENCES public.gestion_stock_typezonedepot(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

